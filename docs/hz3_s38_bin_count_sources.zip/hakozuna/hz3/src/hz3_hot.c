#define _GNU_SOURCE

#include "hz3.h"
#include "hz3_config.h"
#include "hz3_tcache.h"
#include "hz3_large.h"
#include "hz3_segmap.h"
#include "hz3_seg_hdr.h"
#include "hz3_small.h"
#include "hz3_small_v2.h"
#include "hz3_sub4k.h"
#include "hz3_tag.h"
#include "hz3_arena.h"  // Task 3: for hz3_arena_contains_fast()

#include <dlfcn.h>
#include <stddef.h>
#include <stdint.h>
#include <stdlib.h>  // S12-5C: for abort() in FAILFAST mode

// ============================================================================
// RTLD_NEXT fallback functions
// ============================================================================

typedef void* (*Hz3MallocFn)(size_t);
typedef void  (*Hz3FreeFn)(void*);
typedef void* (*Hz3CallocFn)(size_t, size_t);
typedef void* (*Hz3ReallocFn)(void*, size_t);

static inline void* hz3_next_sym(const char* name) {
    return dlsym(RTLD_NEXT, name);
}

static inline void* hz3_next_malloc(size_t size) {
    Hz3MallocFn fn = (Hz3MallocFn)hz3_next_sym("malloc");
    return fn ? fn(size) : NULL;
}

static inline void hz3_next_free(void* ptr) {
    Hz3FreeFn fn = (Hz3FreeFn)hz3_next_sym("free");
    if (fn) fn(ptr);
}

static inline void* hz3_next_calloc(size_t n, size_t s) {
    Hz3CallocFn fn = (Hz3CallocFn)hz3_next_sym("calloc");
    return fn ? fn(n, s) : NULL;
}

static inline void* hz3_next_realloc(void* p, size_t s) {
    Hz3ReallocFn fn = (Hz3ReallocFn)hz3_next_sym("realloc");
    return fn ? fn(p, s) : NULL;
}

// ============================================================================
// Pointer to page index conversion (0-cost, debug-friendly)
// ============================================================================

// Get page index within segment from pointer
static inline size_t hz3_ptr_to_page_idx(void* ptr, void* seg_base) {
    uintptr_t offset = (uintptr_t)ptr - (uintptr_t)seg_base;
    return offset >> HZ3_PAGE_SHIFT;
}

// Get segment base from pointer (2MB aligned)
static inline void* hz3_ptr_to_seg_base(void* ptr) {
    return (void*)((uintptr_t)ptr & ~((uintptr_t)HZ3_SEG_SIZE - 1));
}

// ============================================================================
// S12-5C: Medium (v1) free by tag helper
// ============================================================================

#if HZ3_SMALL_V2_PTAG_ENABLE && HZ3_PTAG_V1_ENABLE
// Free medium allocation (4KB+) using PageTagMap decoded sc/owner
// Uses regular bins (not small_bins) for medium size classes
static inline void hz3_medium_free_by_tag(void* ptr, int sc, int owner) {
    if (!ptr || sc < 0 || sc >= HZ3_NUM_SC) {
        return;
    }

    hz3_tcache_ensure_init();

    if ((uint8_t)owner == t_hz3_cache.my_shard) {
        // Local: push to TLS bin (fast path)
        Hz3Bin* bin = hz3_tcache_get_bin(sc);
        hz3_bin_push(bin, ptr);
        return;
    }

    // Remote: push to outbox (batches to owner's inbox)
    hz3_outbox_push((uint8_t)owner, sc, ptr);
}

#if HZ3_FREE_FASTPATH_SPLIT
// S16-2D: Split v2/v1 medium free into noinline slow-path helpers.
// This reduces live ranges in hz3_free fast path to avoid spills.
__attribute__((noinline)) static void hz3_free_v2_impl(void* ptr, uint16_t tag) {
    int sc, owner;
    hz3_pagetag_decode(tag, &sc, &owner);
    hz3_small_v2_free_by_tag(ptr, sc, owner);
#if HZ3_S12_V2_STATS
    hz3_tcache_ensure_init();
    t_hz3_cache.stats.s12_v2_small_v2_enter++;
#endif
}

__attribute__((noinline)) static void hz3_free_medium_impl(void* ptr, uint16_t tag) {
    int sc, owner;
    hz3_pagetag_decode(tag, &sc, &owner);
    hz3_medium_free_by_tag(ptr, sc, owner);
}
#endif // HZ3_FREE_FASTPATH_SPLIT
#endif

// ============================================================================
// Hot path implementations
// ============================================================================

void* hz3_malloc(size_t size) {
#if !HZ3_ENABLE || HZ3_SHIM_FORWARD_ONLY
    return hz3_next_malloc(size);
#else
    if (size == 0) {
        size = 1;
    }

#if HZ3_SMALL_V2_ENABLE && HZ3_SEG_SELF_DESC_ENABLE
    if (size <= HZ3_SMALL_MAX_SIZE) {
        void* small = hz3_small_v2_alloc(size);
        if (small) {
            return small;
        }
        return hz3_next_malloc(size);
    }
#else
    if (size <= HZ3_SMALL_MAX_SIZE) {
        void* small = hz3_small_alloc(size);
        if (small) {
            return small;
        }
        return hz3_next_malloc(size);
    }
#endif

#if HZ3_SUB4K_ENABLE
    if (size > HZ3_SMALL_MAX_SIZE && size < HZ3_SC_MIN_SIZE) {
        void* sub4k = hz3_sub4k_alloc(size);
        if (sub4k) {
            return sub4k;
        }
        return hz3_next_malloc(size);
    }
#endif

    if (size < HZ3_SC_MIN_SIZE) {
        size = HZ3_SC_MIN_SIZE;
    }

    // Convert size to size class
    int sc = hz3_sc_from_size(size);
    if (sc < 0) {
        if (size > HZ3_SC_MAX_SIZE) {
            return hz3_large_alloc(size);
        }
        // Out of range, fallback
        return hz3_next_malloc(size);
    }

    // Ensure TLS cache is initialized
#if !HZ3_TCACHE_INIT_ON_MISS
    hz3_tcache_ensure_init();
#endif
    // S32-1: When HZ3_TCACHE_INIT_ON_MISS=1, skip init here.
    // TLS is zero-initialized, so bin->head == NULL → miss → slow path → init there.

    // Try to pop from bin (fast path)
    Hz3Bin* bin = hz3_tcache_get_bin(sc);
    void* obj = hz3_bin_pop(bin);
    if (obj) {
        return obj;
    }

    // Slow path: allocate new
    return hz3_alloc_slow(sc);
#endif
}

void hz3_free(void* ptr) {
#if !HZ3_ENABLE || HZ3_SHIM_FORWARD_ONLY
    hz3_next_free(ptr);
#else
    // NULL check
    if (!ptr) {
        return;
    }

#if HZ3_SMALL_V2_ENABLE && HZ3_SEG_SELF_DESC_ENABLE
#if HZ3_SMALL_V2_PTAG_ENABLE

#if HZ3_PTAG_V1_ENABLE
    // S12-5C: Unified dispatch via PageTagMap (both v1 and v2)
    // Step 1: range check (comparison only, no used[] read)
#if HZ3_PTAG_DSTBIN_ENABLE
#if HZ3_PTAG_DSTBIN_FASTLOOKUP

#if HZ3_PTAG32_NOINRANGE
    // S28-5: hit-only lookup (no in_range store on hit path)
    uint32_t tag32 = 0;
    if (hz3_pagetag32_lookup_hit_fast(ptr, &tag32)) {
        hz3_tcache_ensure_init();
#if HZ3_PTAG_DSTBIN_FLAT
        uint32_t flat = hz3_pagetag32_flat(tag32);
#if HZ3_PTAG_FAILFAST
        if (flat >= (HZ3_NUM_SHARDS * HZ3_BIN_TOTAL)) {
            abort();
        }
#endif
        hz3_bin_push(hz3_tcache_get_bank_bin_flat(flat), ptr);
#else
        uint32_t bin = hz3_pagetag32_bin(tag32);
        uint8_t dst = hz3_pagetag32_dst(tag32);
#if HZ3_PTAG_FAILFAST
        if (bin >= HZ3_BIN_TOTAL || dst >= HZ3_NUM_SHARDS) {
            abort();
        }
#endif
#if HZ3_LOCAL_BINS_SPLIT
        if (dst == t_hz3_cache.my_shard) {
            hz3_bin_push(hz3_tcache_get_local_bin_from_bin_index(bin), ptr);
        } else {
            hz3_bin_push(hz3_tcache_get_bank_bin(dst, bin), ptr);
        }
#else
        hz3_bin_push(hz3_tcache_get_bank_bin(dst, bin), ptr);
#endif
#endif
        return;
    }
    // S28-5: miss path - separate range check (miss is rare)
    if (!hz3_arena_page_index_fast(ptr, NULL)) {
        // Arena external → large/fallback
        if (hz3_large_free(ptr)) {
            return;
        }
        hz3_next_free(ptr);
        return;
    }
    // Arena internal, tag==0: existing failfast/no-op behavior
#if HZ3_PTAG_FAILFAST
    abort();  // Debug mode: fail fast
#else
    return;   // Release mode: silent no-op
#endif

#else // !HZ3_PTAG32_NOINRANGE
    // Original path with in_range out-param
    uint32_t tag32 = 0;
    int in_range = 0;
    if (hz3_pagetag32_lookup_fast(ptr, &tag32, &in_range)) {
        hz3_tcache_ensure_init();
#if HZ3_PTAG_DSTBIN_FLAT
        uint32_t flat = hz3_pagetag32_flat(tag32);
#if HZ3_PTAG_FAILFAST
        if (flat >= (HZ3_NUM_SHARDS * HZ3_BIN_TOTAL)) {
            abort();
        }
#endif
        hz3_bin_push(hz3_tcache_get_bank_bin_flat(flat), ptr);
#else
        uint32_t bin = hz3_pagetag32_bin(tag32);
        uint8_t dst = hz3_pagetag32_dst(tag32);
#if HZ3_PTAG_FAILFAST
        if (bin >= HZ3_BIN_TOTAL || dst >= HZ3_NUM_SHARDS) {
            abort();
        }
#endif
#if HZ3_LOCAL_BINS_SPLIT
        if (dst == t_hz3_cache.my_shard) {
            // S28-2C: Local: push to local bins (shallow TLS offset)
            hz3_bin_push(hz3_tcache_get_local_bin_from_bin_index(bin), ptr);
        } else {
            // Remote: push to bank (owner transfer later)
            hz3_bin_push(hz3_tcache_get_bank_bin(dst, bin), ptr);
        }
#else
        hz3_bin_push(hz3_tcache_get_bank_bin(dst, bin), ptr);
#endif
#endif
        return;
    }
    if (!in_range) {
        // Arena external → large/fallback
        if (hz3_large_free(ptr)) {
            return;
        }
        hz3_next_free(ptr);
        return;
    }
#if HZ3_PTAG_FAILFAST
    abort();  // Debug mode: fail fast
#else
    return;   // Release mode: silent no-op
#endif
#endif // HZ3_PTAG32_NOINRANGE
#elif HZ3_PTAG_DSTBIN_TLS
    void* arena_base = t_hz3_cache.arena_base;
    _Atomic(uint32_t)* tag32_base = t_hz3_cache.page_tag32;
    if (__builtin_expect(!arena_base, 0)) {
        arena_base = atomic_load_explicit(&g_hz3_arena_base, memory_order_acquire);
        t_hz3_cache.arena_base = arena_base;
    }
    if (__builtin_expect(!arena_base, 0)) {
        // Arena external → large/fallback
        if (hz3_large_free(ptr)) {
            return;
        }
        hz3_next_free(ptr);
        return;
    }
    if (__builtin_expect(!tag32_base, 0)) {
        tag32_base = g_hz3_page_tag32;
        t_hz3_cache.page_tag32 = tag32_base;
    }
    if (tag32_base) {
        uintptr_t delta = (uintptr_t)ptr - (uintptr_t)arena_base;
#if HZ3_ARENA_SIZE == (1ULL << 32)
        if (__builtin_expect((delta >> 32) != 0, 0)) {
#else
        if (__builtin_expect(delta >= (uintptr_t)HZ3_ARENA_SIZE, 0)) {
#endif
            // Arena external → large/fallback
            if (hz3_large_free(ptr)) {
                return;
            }
            hz3_next_free(ptr);
            return;
        }
        uint32_t page_idx = (uint32_t)(delta >> HZ3_ARENA_PAGE_SHIFT);
        uint32_t tag32_tls = atomic_load_explicit(&tag32_base[page_idx], memory_order_relaxed);
        if (tag32_tls == 0) {
#if HZ3_PTAG_FAILFAST
            abort();  // Debug mode: fail fast
#else
            return;   // Release mode: silent no-op
#endif
        }

        hz3_tcache_ensure_init();
#if HZ3_PTAG_DSTBIN_FLAT
        uint32_t flat = hz3_pagetag32_flat(tag32_tls);
#if HZ3_PTAG_FAILFAST
        if (flat >= (HZ3_NUM_SHARDS * HZ3_BIN_TOTAL)) {
            abort();
        }
#endif
        hz3_bin_push(hz3_tcache_get_bank_bin_flat(flat), ptr);
#else
        uint32_t bin = hz3_pagetag32_bin(tag32_tls);
        uint8_t dst = hz3_pagetag32_dst(tag32_tls);
#if HZ3_PTAG_FAILFAST
        if (bin >= HZ3_BIN_TOTAL || dst >= HZ3_NUM_SHARDS) {
            abort();
        }
#endif
#if HZ3_LOCAL_BINS_SPLIT
        if (dst == t_hz3_cache.my_shard) {
            // S28-2C: Local: push to local bins (shallow TLS offset)
            hz3_bin_push(hz3_tcache_get_local_bin_from_bin_index(bin), ptr);
        } else {
            // Remote: push to bank (owner transfer later)
            hz3_bin_push(hz3_tcache_get_bank_bin(dst, bin), ptr);
        }
#else
        hz3_bin_push(hz3_tcache_get_bank_bin(dst, bin), ptr);
#endif
#endif
        return;
    }
#else
    if (g_hz3_page_tag32) {
        uint32_t page_idx;
        if (!hz3_arena_page_index_fast(ptr, &page_idx)) {
            // Arena external → large/fallback
            if (hz3_large_free(ptr)) {
                return;
            }
            hz3_next_free(ptr);
            return;
        }
        uint32_t tag32 = hz3_pagetag32_load(page_idx);
        if (tag32 == 0) {
#if HZ3_PTAG_FAILFAST
            abort();  // Debug mode: fail fast
#else
            return;   // Release mode: silent no-op
#endif
        }

        hz3_tcache_ensure_init();
#if HZ3_PTAG_DSTBIN_FLAT
        uint32_t flat = hz3_pagetag32_flat(tag32);
#if HZ3_PTAG_FAILFAST
        if (flat >= (HZ3_NUM_SHARDS * HZ3_BIN_TOTAL)) {
            abort();
        }
#endif
        hz3_bin_push(hz3_tcache_get_bank_bin_flat(flat), ptr);
#else
        uint32_t bin = hz3_pagetag32_bin(tag32);
        uint8_t dst = hz3_pagetag32_dst(tag32);
#if HZ3_PTAG_FAILFAST
        if (bin >= HZ3_BIN_TOTAL || dst >= HZ3_NUM_SHARDS) {
            abort();
        }
#endif
#if HZ3_LOCAL_BINS_SPLIT
        if (dst == t_hz3_cache.my_shard) {
            // S28-2C: Local: push to local bins (shallow TLS offset)
            hz3_bin_push(hz3_tcache_get_local_bin_from_bin_index(bin), ptr);
        } else {
            // Remote: push to bank (owner transfer later)
            hz3_bin_push(hz3_tcache_get_bank_bin(dst, bin), ptr);
        }
#else
        hz3_bin_push(hz3_tcache_get_bank_bin(dst, bin), ptr);
#endif
#endif
        return;
    }
#endif
#endif

#if HZ3_V2_ONLY
    // V2-only: PTAG32 (dst/bin) dispatch must have handled all in-arena pointers above.
    // Reaching here means "in arena but no tag32" (bug/double-free/uninitialized).
#if HZ3_PTAG_FAILFAST
    abort();
#else
    return;
#endif
#endif // HZ3_V2_ONLY

#if !HZ3_V2_ONLY
    uint32_t page_idx;
    if (!hz3_arena_page_index_fast(ptr, &page_idx)) {
        // Arena external → large/fallback
        if (hz3_large_free(ptr)) {
            return;
        }
        hz3_next_free(ptr);
        return;
    }

    // Step 2: tag load (1 load)
    uint16_t tag = hz3_pagetag_load(page_idx);
    if (tag == 0) {
        // S12-5C: Arena-internal but tag==0 means unallocated/freed
        // Don't pass to hz3_next_free() - that hides mixed allocation bugs
#if HZ3_PTAG_FAILFAST
        abort();  // Debug mode: fail fast
#else
        return;   // Release mode: silent no-op (double-free equivalent)
#endif
    }

    // Step 3: dispatch by kind
#if HZ3_FREE_FASTPATH_SPLIT
    int kind = tag >> 14;
    if (kind == PTAG_KIND_V2) {
        hz3_free_v2_impl(ptr, tag);
        return;
    }
    if (kind == PTAG_KIND_V1_MEDIUM) {
        hz3_free_medium_impl(ptr, tag);
        return;
    }
#else
    int sc, owner, kind;
    hz3_pagetag_decode_with_kind(tag, &sc, &owner, &kind);

    switch (kind) {
        case PTAG_KIND_V2:
            hz3_small_v2_free_by_tag(ptr, sc, owner);
#if HZ3_S12_V2_STATS
            hz3_tcache_ensure_init();
            t_hz3_cache.stats.s12_v2_small_v2_enter++;
#endif
            return;
        case PTAG_KIND_V1_MEDIUM:
            hz3_medium_free_by_tag(ptr, sc, owner);
            return;
        default:
            break;
    }
#endif
    // Unknown kind → no-op (don't crash in production)
#if HZ3_PTAG_FAILFAST
    abort();
#else
    return;
#endif

#endif // !HZ3_V2_ONLY

#else  // !HZ3_PTAG_V1_ENABLE
    // S12-4C: PageTagMap hot path (v2 only, v1 falls through to segmap)
    // Step 1: range check (比較のみ、used[] を読まない)
    uint32_t page_idx;
    if (hz3_arena_page_index_fast(ptr, &page_idx)) {
        // Step 2: tag load (1 load - miss側はここで終わり!)
        uint16_t tag = hz3_pagetag_load(page_idx);
        if (tag != 0) {
            // Step 3: decode & process (no page_hdr read)
            int sc, owner;
            hz3_pagetag_decode(tag, &sc, &owner);
            hz3_small_v2_free_by_tag(ptr, sc, owner);
#if HZ3_S12_V2_STATS
            hz3_tcache_ensure_init();
            t_hz3_cache.stats.s12_v2_small_v2_enter++;
#endif
            return;
        }
        // tag == 0: not a small v2 page, fall through to v1 path
    }
#endif  // HZ3_PTAG_V1_ENABLE

#else  // !HZ3_SMALL_V2_PTAG_ENABLE
    // Task 3: page_hdr based detection (no seg_hdr cold reads)
    // Step 1: arena range check (必ず先に弾く - arena外のptrでpage_hdrを読むのは危険)
    uint32_t arena_idx;
    void* arena_base;
    if (hz3_arena_contains_fast(ptr, &arena_idx, &arena_base)) {
        // Step 2: page_hdr->magic で small v2 判定
        void* page_base = (void*)((uintptr_t)ptr & ~((uintptr_t)HZ3_PAGE_SIZE - 1u));
        uint32_t magic = *(uint32_t*)page_base;
        if (magic == HZ3_PAGE_MAGIC) {
            hz3_small_v2_free_fast(ptr, page_base);
#if HZ3_S12_V2_STATS
            // TLS initialized by hz3_small_v2_free_fast()
            t_hz3_cache.stats.s12_v2_small_v2_enter++;
#endif
            return;
        }
        // Not a small v2 page - fall through to v1 path
    }
#endif // HZ3_SMALL_V2_PTAG_ENABLE
#endif // HZ3_SMALL_V2_ENABLE && HZ3_SEG_SELF_DESC_ENABLE

#if !(HZ3_SMALL_V2_PTAG_ENABLE && HZ3_PTAG_V1_ENABLE)
    // v1 fallback path: only needed when PTAG unified dispatch is not enabled
    // When HZ3_PTAG_V1_ENABLE=1, all v1/v2 handled via PageTagMap above

    // Look up segment metadata (lock-free)
    Hz3SegMeta* meta = hz3_segmap_get(ptr);
    if (!meta) {
        if (hz3_large_free(ptr)) {
            return;
        }
        // Not our allocation, fallback
        hz3_next_free(ptr);
        return;
    }

    // Get page index within segment (v1 path)
    void* seg_base = hz3_ptr_to_seg_base(ptr);
    size_t seg_page_idx = hz3_ptr_to_page_idx(ptr, seg_base);

    // Read tag (hot path: read-only)
    uint16_t tag = meta->sc_tag[seg_page_idx];
    if (tag == 0) {
        // Not cached / unknown, fallback
        hz3_next_free(ptr);
        return;
    }

    uint8_t kind = hz3_tag_kind(tag);
    int sc = hz3_tag_sc(tag);
    if (kind == HZ3_TAG_KIND_SMALL) {
        hz3_small_free(ptr, sc);
        return;
    }
    if (kind != HZ3_TAG_KIND_LARGE) {
        hz3_next_free(ptr);
        return;
    }

    // Ensure TLS cache is initialized
    hz3_tcache_ensure_init();

    // Day 4: Local vs Remote free
    uint8_t owner = meta->owner;
    if (owner == t_hz3_cache.my_shard) {
        // Local: push to bin (fast path)
        Hz3Bin* bin = hz3_tcache_get_bin(sc);
        hz3_bin_push(bin, ptr);
    } else {
        // Remote: push to outbox (batches to inbox)
        hz3_outbox_push(owner, sc, ptr);
    }
#endif // !(HZ3_SMALL_V2_PTAG_ENABLE && HZ3_PTAG_V1_ENABLE)
#endif // HZ3_ENABLE && !HZ3_SHIM_FORWARD_ONLY
}

void* hz3_calloc(size_t nmemb, size_t size) {
#if !HZ3_ENABLE || HZ3_SHIM_FORWARD_ONLY
    return hz3_next_calloc(nmemb, size);
#else
    // Calculate total size with overflow check
    size_t total;
    if (__builtin_mul_overflow(nmemb, size, &total)) {
        return NULL;
    }

    // Try hz3 allocation
    void* ptr = hz3_malloc(total);
    if (!ptr) {
        return NULL;
    }

    // Zero memory (mmap gives zeroed pages, but be safe for reused allocations)
    __builtin_memset(ptr, 0, total);
    return ptr;
#endif
}

void* hz3_realloc(void* ptr, size_t size) {
#if !HZ3_ENABLE || HZ3_SHIM_FORWARD_ONLY
    return hz3_next_realloc(ptr, size);
#else
    // realloc(NULL, size) == malloc(size)
    if (!ptr) {
        return hz3_malloc(size);
    }

    // realloc(ptr, 0) == free(ptr), return NULL
    if (size == 0) {
        hz3_free(ptr);
        return NULL;
    }

#if HZ3_PTAG_DSTBIN_ENABLE && HZ3_PTAG_DSTBIN_FASTLOOKUP && HZ3_REALLOC_PTAG32
    // S21: PTAG32-first realloc (bin->size via PTAG32)
    uint32_t tag32;
    int in_range = 0;
    if (hz3_pagetag32_lookup_fast(ptr, &tag32, &in_range)) {
        uint32_t bin = hz3_pagetag32_bin(tag32);
        size_t old_size = hz3_bin_to_usable_size(bin);
        if (old_size == 0) {
#if HZ3_PTAG_FAILFAST
            abort();
#else
            return NULL;
#endif
        }
        if (size <= old_size) {
            return ptr;
        }
        void* new_ptr = hz3_malloc(size);
        if (!new_ptr) {
            return NULL;
        }
        size_t copy_size = (size < old_size) ? size : old_size;
        __builtin_memcpy(new_ptr, ptr, copy_size);
        hz3_free(ptr);
        return new_ptr;
    }
    // S21-2: in_range && tag==0 → fall through to slow path
    // (arena内だが tag 未設定、foreign に渡さない)
#if HZ3_PTAG_FAILFAST
    if (in_range) {
        abort();
    }
#endif
    // Fall through to slow path (PTAG32 fast path ended)
#endif

#if HZ3_SMALL_V2_ENABLE && HZ3_SEG_SELF_DESC_ENABLE
#if HZ3_SMALL_V2_PTAG_ENABLE
    // S12-4C: PageTagMap hot path (range check + 1 load only)
    uint32_t page_idx;
    if (hz3_arena_page_index_fast(ptr, &page_idx)) {
        uint16_t tag = hz3_pagetag_load(page_idx);
        if (tag != 0) {
            int sc, owner;
            hz3_pagetag_decode(tag, &sc, &owner);
            size_t old_size = hz3_small_sc_to_size(sc);  // tag decode で算出
            if (size <= old_size) {
                return ptr;
            }
            void* new_ptr = hz3_malloc(size);
            if (!new_ptr) {
                return NULL;
            }
            size_t copy_size = (size < old_size) ? size : old_size;
            __builtin_memcpy(new_ptr, ptr, copy_size);
            hz3_small_v2_free_by_tag(ptr, sc, owner);
            return new_ptr;
        }
        // tag == 0: not a small v2 page, fall through to v1 path
    }
#else
    // Task 3: page_hdr based detection (no seg_hdr cold reads)
    uint32_t arena_idx;
    void* arena_base;
    if (hz3_arena_contains_fast(ptr, &arena_idx, &arena_base)) {
        void* page_base = (void*)((uintptr_t)ptr & ~((uintptr_t)HZ3_PAGE_SIZE - 1u));
        uint32_t magic = *(uint32_t*)page_base;
        if (magic == HZ3_PAGE_MAGIC) {
            size_t old_size = hz3_small_v2_usable_size(ptr);
            if (size <= old_size) {
                return ptr;
            }
            void* new_ptr = hz3_malloc(size);
            if (!new_ptr) {
                return NULL;
            }
            size_t copy_size = (size < old_size) ? size : old_size;
            __builtin_memcpy(new_ptr, ptr, copy_size);
            hz3_small_v2_free_fast(ptr, page_base);
            return new_ptr;
        }
        // Not a small v2 page - fall through to v1 path
    }
#endif // HZ3_SMALL_V2_PTAG_ENABLE
#endif // HZ3_SMALL_V2_ENABLE && HZ3_SEG_SELF_DESC_ENABLE

    // Check if ptr is ours
    Hz3SegMeta* meta = hz3_segmap_get(ptr);
    if (!meta) {
        size_t old_large_size = hz3_large_usable_size(ptr);
        if (old_large_size != 0) {
            if (size > HZ3_SC_MAX_SIZE && size <= old_large_size) {
                return ptr;
            }
            void* new_ptr = hz3_malloc(size);
            if (!new_ptr) {
                return NULL;
            }
            size_t copy_size = (size < old_large_size) ? size : old_large_size;
            __builtin_memcpy(new_ptr, ptr, copy_size);
            hz3_large_free(ptr);
            return new_ptr;
        }
        // Not our allocation, fallback
        return hz3_next_realloc(ptr, size);
    }

    // Get current size class (v1 path)
    void* seg_base = hz3_ptr_to_seg_base(ptr);
    size_t seg_page_idx = hz3_ptr_to_page_idx(ptr, seg_base);
    uint16_t tag = meta->sc_tag[seg_page_idx];

    if (tag == 0) {
        // Unknown, fallback
        return hz3_next_realloc(ptr, size);
    }

    uint8_t kind = hz3_tag_kind(tag);
    int old_sc = hz3_tag_sc(tag);
    size_t old_size = 0;
    if (kind == HZ3_TAG_KIND_SMALL) {
        old_size = hz3_small_sc_to_size(old_sc);
    } else if (kind == HZ3_TAG_KIND_LARGE) {
        old_size = hz3_sc_to_size(old_sc);
    } else {
        return hz3_next_realloc(ptr, size);
    }

    if (size <= old_size) {
        return ptr;
    }

    // Need to reallocate
    void* new_ptr = hz3_malloc(size);
    if (!new_ptr) {
        return NULL;
    }

    // Copy old data (min of old and new size)
    size_t copy_size = (size < old_size) ? size : old_size;
    __builtin_memcpy(new_ptr, ptr, copy_size);

    // Free old
    hz3_free(ptr);

    return new_ptr;
#endif
}

// ============================================================================
// hz3_usable_size: Get usable size of hz3-allocated pointer
// Used by hybrid shim for cross-allocator realloc
// ============================================================================

size_t hz3_usable_size(void* ptr) {
    if (!ptr) {
        return 0;
    }

#if HZ3_PTAG_DSTBIN_ENABLE && HZ3_PTAG_DSTBIN_FASTLOOKUP && HZ3_USABLE_SIZE_PTAG32
    // S21: PTAG32-first usable_size (bin->size via PTAG32)
    uint32_t tag32;
    int in_range = 0;
    if (hz3_pagetag32_lookup_fast(ptr, &tag32, &in_range)) {
        uint32_t bin = hz3_pagetag32_bin(tag32);
        return hz3_bin_to_usable_size(bin);
    }
    // S21-2: in_range && tag==0 → fall through to slow path
    // (arena内だが tag 未設定、foreign に渡さない)
#if HZ3_PTAG_FAILFAST
    if (in_range) {
        abort();
    }
#endif
    // Fall through to slow path (PTAG32 fast path ended)
#endif

#if HZ3_SMALL_V2_ENABLE && HZ3_SEG_SELF_DESC_ENABLE
#if HZ3_SMALL_V2_PTAG_ENABLE
    // S12-4C: PageTagMap hot path (range check + 1 load only)
    uint32_t page_idx;
    if (hz3_arena_page_index_fast(ptr, &page_idx)) {
        uint16_t tag = hz3_pagetag_load(page_idx);
        if (tag != 0) {
            int sc, owner;
            (void)owner;  // unused for usable_size
            hz3_pagetag_decode(tag, &sc, &owner);
            return hz3_small_sc_to_size(sc);
        }
        // tag == 0: not a small v2 page, fall through to v1 path
    }
#else
    // Task 3: page_hdr based detection (no seg_hdr cold reads)
    uint32_t arena_idx;
    void* arena_base;
    if (hz3_arena_contains_fast(ptr, &arena_idx, &arena_base)) {
        void* page_base = (void*)((uintptr_t)ptr & ~((uintptr_t)HZ3_PAGE_SIZE - 1u));
        uint32_t magic = *(uint32_t*)page_base;
        if (magic == HZ3_PAGE_MAGIC) {
            return hz3_small_v2_usable_size(ptr);
        }
        // Not a small v2 page - fall through to v1 path
    }
#endif // HZ3_SMALL_V2_PTAG_ENABLE
#endif // HZ3_SMALL_V2_ENABLE && HZ3_SEG_SELF_DESC_ENABLE

    // Look up segment metadata
    Hz3SegMeta* meta = hz3_segmap_get(ptr);
    if (!meta) {
        return hz3_large_usable_size(ptr);
    }

    // Get page index within segment (v1 path)
    void* seg_base = hz3_ptr_to_seg_base(ptr);
    size_t seg_page_idx = hz3_ptr_to_page_idx(ptr, seg_base);

    // Read tag
    uint16_t tag = meta->sc_tag[seg_page_idx];
    if (tag == 0) {
        return 0;  // Not cached / unknown
    }

    // Convert tag to size class, then to size
    uint8_t kind = hz3_tag_kind(tag);
    int sc = hz3_tag_sc(tag);
    if (kind == HZ3_TAG_KIND_SMALL) {
        return hz3_small_sc_to_size(sc);
    }
    if (kind == HZ3_TAG_KIND_LARGE) {
        return hz3_sc_to_size(sc);
    }
    return 0;
}
