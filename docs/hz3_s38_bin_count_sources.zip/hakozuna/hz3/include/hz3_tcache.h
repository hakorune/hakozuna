#pragma once

#include "hz3_types.h"
#include "hz3_sc.h"
#include "hz3_small.h"
#if HZ3_SUB4K_ENABLE
#include "hz3_sub4k.h"
#endif

// ============================================================================
// Intrusive linked list pointer operations (0-cost, debug-friendly)
// ============================================================================

// Get next pointer from object (intrusive list: next stored at obj[0])
static inline void* hz3_obj_get_next(void* obj) {
    return *(void**)obj;
}

// Set next pointer in object
static inline void hz3_obj_set_next(void* obj, void* next) {
    *(void**)obj = next;
}

// ============================================================================
// TLS Bin operations (push/pop)
// ============================================================================

// Push object to bin head (LIFO)
static inline void hz3_bin_push(Hz3Bin* bin, void* obj) {
    hz3_obj_set_next(obj, bin->head);
    bin->head = obj;
    bin->count++;
}

// Pop object from bin head (returns NULL if empty)
static inline void* hz3_bin_pop(Hz3Bin* bin) {
    void* obj = bin->head;
    if (obj) {
        bin->head = hz3_obj_get_next(obj);
        bin->count--;
    }
    return obj;
}

// S28-2B: nocount 版 push/pop (small hot path 用)
#if HZ3_SMALL_BIN_NOCOUNT
static inline void hz3_small_bin_push(Hz3Bin* bin, void* obj) {
    hz3_obj_set_next(obj, bin->head);
    bin->head = obj;
}

static inline void* hz3_small_bin_pop(Hz3Bin* bin) {
    void* obj = bin->head;
    if (obj) {
        bin->head = hz3_obj_get_next(obj);
    }
    return obj;
}
#else
#define hz3_small_bin_push hz3_bin_push
#define hz3_small_bin_pop hz3_bin_pop
#endif

// Check if bin is empty
static inline int hz3_bin_is_empty(Hz3Bin* bin) {
    return bin->head == NULL;
}

// Convert unified bin index to usable size (bytes). Returns 0 if invalid.
static inline size_t hz3_bin_to_usable_size(uint32_t bin) {
    if (bin < HZ3_SMALL_NUM_SC) {
        return hz3_small_sc_to_size((int)bin);
    }
#if HZ3_SUB4K_ENABLE
    if (bin < HZ3_MEDIUM_BIN_BASE) {
        return hz3_sub4k_sc_to_size((int)(bin - HZ3_SUB4K_BIN_BASE));
    }
#endif
    if (bin < HZ3_BIN_TOTAL) {
        return hz3_sc_to_size((int)(bin - HZ3_MEDIUM_BIN_BASE));
    }
    return 0;
}

// ============================================================================
// TLS Cache
// ============================================================================

// Thread-local cache (defined in hz3_tcache.c)
extern __thread Hz3TCache t_hz3_cache;

// Ensure TLS cache is initialized (call before any bin access)
void hz3_tcache_ensure_init_slow(void);
static inline void hz3_tcache_ensure_init(void) {
    if (__builtin_expect(t_hz3_cache.initialized, 1)) {
        return;
    }
    hz3_tcache_ensure_init_slow();
}

// Get bin for size class (assumes initialized)
#if HZ3_PTAG_DSTBIN_ENABLE
static inline int hz3_bin_index_small(int sc) {
    return sc;
}

#if HZ3_SUB4K_ENABLE
static inline int hz3_bin_index_sub4k(int sc) {
    return HZ3_SUB4K_BIN_BASE + sc;
}
#endif

static inline int hz3_bin_index_medium(int sc) {
    return HZ3_MEDIUM_BIN_BASE + sc;
}

static inline Hz3Bin* hz3_tcache_get_bin(int sc) {
#if HZ3_LOCAL_BINS_SPLIT
    // S33: Use unified local_bins (no range check)
    return &t_hz3_cache.local_bins[hz3_bin_index_medium(sc)];
#elif HZ3_TCACHE_BANK_ROW_CACHE
    // S28-2A: Use cached bank row base (shorter dependency chain)
    return &t_hz3_cache.bank_my[hz3_bin_index_medium(sc)];
#else
    return &t_hz3_cache.bank[t_hz3_cache.my_shard][hz3_bin_index_medium(sc)];
#endif
}

static inline Hz3Bin* hz3_tcache_get_small_bin(int sc) {
#if HZ3_LOCAL_BINS_SPLIT
    // S33: Use unified local_bins (no range check)
    return &t_hz3_cache.local_bins[hz3_bin_index_small(sc)];
#elif HZ3_TCACHE_BANK_ROW_CACHE
    // S28-2A: Use cached bank row base (shorter dependency chain)
    return &t_hz3_cache.bank_my[hz3_bin_index_small(sc)];
#else
    return &t_hz3_cache.bank[t_hz3_cache.my_shard][hz3_bin_index_small(sc)];
#endif
}

#if HZ3_SUB4K_ENABLE
static inline Hz3Bin* hz3_tcache_get_sub4k_bin(int sc) {
#if HZ3_LOCAL_BINS_SPLIT
    // S33: Use unified local_bins (no range check)
    return &t_hz3_cache.local_bins[hz3_bin_index_sub4k(sc)];
#elif HZ3_TCACHE_BANK_ROW_CACHE
    // S28-2A: Use cached bank row base (shorter dependency chain)
    return &t_hz3_cache.bank_my[hz3_bin_index_sub4k(sc)];
#else
    return &t_hz3_cache.bank[t_hz3_cache.my_shard][hz3_bin_index_sub4k(sc)];
#endif
}
#endif

static inline Hz3Bin* hz3_tcache_get_bank_bin(uint8_t dst, uint32_t bin) {
    return &t_hz3_cache.bank[dst][bin];
}

// S33: bin index から local bin を取得（分岐なし）
#if HZ3_LOCAL_BINS_SPLIT
static inline Hz3Bin* hz3_tcache_get_local_bin_from_bin_index(uint32_t bin) {
    // S33: Direct array access (no range check, bin comes from PTAG32)
    return &t_hz3_cache.local_bins[bin];
}
#endif

#if HZ3_PTAG_DSTBIN_FLAT
static inline Hz3Bin* hz3_tcache_get_bank_bin_flat(uint32_t flat) {
    return &t_hz3_cache.bank[0][0] + flat;
}
#endif
#else
// Non-PTAG_DSTBIN_ENABLE fallback (HZ3_LOCAL_BINS_SPLIT should be 0 here)
static inline Hz3Bin* hz3_tcache_get_bin(int sc) {
#if HZ3_LOCAL_BINS_SPLIT
    return &t_hz3_cache.local_bins[HZ3_MEDIUM_BIN_BASE + sc];
#else
    return &t_hz3_cache.bins[sc];
#endif
}

// Get small bin for size class (assumes initialized)
static inline Hz3Bin* hz3_tcache_get_small_bin(int sc) {
#if HZ3_LOCAL_BINS_SPLIT
    return &t_hz3_cache.local_bins[sc];
#else
    return &t_hz3_cache.small_bins[sc];
#endif
}
#endif

// ============================================================================
// Slow path functions (implemented in hz3_tcache.c)
// ============================================================================

// Allocate from slow path (called when bin is empty)
void* hz3_alloc_slow(int sc);

// ============================================================================
// Day 4: Outbox operations (implemented in hz3_tcache.c)
// ============================================================================

// Push object to outbox (flushes automatically when full)
void hz3_outbox_push(uint8_t owner, int sc, void* obj);

// Flush outbox to owner's inbox
void hz3_outbox_flush(uint8_t owner, int sc);

#if HZ3_PTAG_DSTBIN_ENABLE
// S24-1: Budgeted flush (round-robin, fixed cost per refill)
void hz3_dstbin_flush_remote_budget(uint32_t budget_bins);
// S24-1: Full flush (all bins, for epoch/destructor)
void hz3_dstbin_flush_remote_all(void);
#endif
