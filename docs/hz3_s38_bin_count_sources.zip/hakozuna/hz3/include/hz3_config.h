#pragma once

// hz3 is developed as a separate track. The LD_PRELOAD shim may exist even when
// hz3 is not fully implemented yet.

// When 0, the shim forwards to the next allocator (RTLD_NEXT) and does not
// change behavior.
#ifndef HZ3_ENABLE
#define HZ3_ENABLE 0
#endif

// Safety: for early bring-up, prefer forwarding unless explicitly enabled.
#ifndef HZ3_SHIM_FORWARD_ONLY
#define HZ3_SHIM_FORWARD_ONLY 1
#endif

// Learning layer is event-only by design (no hot-path reads of global knobs).
#ifndef HZ3_LEARN_ENABLE
#define HZ3_LEARN_ENABLE 0
#endif

// Small v2 (self-describing) gate
#ifndef HZ3_SMALL_V2_ENABLE
#define HZ3_SMALL_V2_ENABLE 0
#endif

// Small v1 gate (legacy path). Default OFF when v2 is available.
#ifndef HZ3_SMALL_V1_ENABLE
#define HZ3_SMALL_V1_ENABLE 0
#endif

// S23: sub-4KB classes (2049..4095) to avoid 4KB rounding.
#ifndef HZ3_SUB4K_ENABLE
#define HZ3_SUB4K_ENABLE 0
#endif

#ifndef HZ3_SUB4K_NUM_SC
#define HZ3_SUB4K_NUM_SC 4
#endif

// v2-only dispatch: use PageTagMap only, no segmap fallback.
// Requires HZ3_SMALL_V2_PTAG_ENABLE=1 and HZ3_SEG_SELF_DESC_ENABLE=1.
#ifndef HZ3_V2_ONLY
#define HZ3_V2_ONLY 0
#endif

#if HZ3_V2_ONLY
// V2-only relies on PTAG32 (dst/bin) as the single in-arena dispatch for free().
// Keep this strict so we don't accidentally compile a "return everything" build.
#if !HZ3_SMALL_V2_PTAG_ENABLE || !HZ3_SEG_SELF_DESC_ENABLE || !HZ3_PTAG_V1_ENABLE
#error "HZ3_V2_ONLY requires HZ3_SMALL_V2_PTAG_ENABLE=1, HZ3_SEG_SELF_DESC_ENABLE=1, HZ3_PTAG_V1_ENABLE=1"
#endif
#if !HZ3_PTAG_DSTBIN_ENABLE || !HZ3_PTAG_DSTBIN_FASTLOOKUP
#error "HZ3_V2_ONLY requires HZ3_PTAG_DSTBIN_ENABLE=1 and HZ3_PTAG_DSTBIN_FASTLOOKUP=1"
#endif
#endif

// v2-only PageTagMap coverage stats (TLS + atexit dump).
#ifndef HZ3_V2_ONLY_STATS
#define HZ3_V2_ONLY_STATS 0
#endif

// Self-describing segment header gate
#ifndef HZ3_SEG_SELF_DESC_ENABLE
#define HZ3_SEG_SELF_DESC_ENABLE 0
#endif

// Debug-only fail-fast for self-describing segments
#ifndef HZ3_SMALL_V2_FAILFAST
#define HZ3_SMALL_V2_FAILFAST 0
#endif

// Small v2 performance statistics (compile-time gated, TLS + atexit dump)
#ifndef HZ3_S12_V2_STATS
#define HZ3_S12_V2_STATS 0
#endif

// Small v2 PageTagMap (arena page-level tag for O(1) ptr→(sc,owner) lookup)
// Requires HZ3_SMALL_V2_ENABLE=1 && HZ3_SEG_SELF_DESC_ENABLE=1
#ifndef HZ3_SMALL_V2_PTAG_ENABLE
#define HZ3_SMALL_V2_PTAG_ENABLE 0
#endif

// S12-5B: PTAG for v1 (4KB-32KB) allocations
// Requires HZ3_SMALL_V2_PTAG_ENABLE=1 (uses same PageTagMap infrastructure)
// When enabled, v1 allocations also set page tags for unified dispatch
#ifndef HZ3_PTAG_V1_ENABLE
#define HZ3_PTAG_V1_ENABLE 0
#endif

// S12-5C: Fail-fast mode for PTAG errors
// When 1: abort() on tag==0 in arena (debug mode)
// When 0: silent no-op (release mode, safer for production)
#ifndef HZ3_PTAG_FAILFAST
#define HZ3_PTAG_FAILFAST 0
#endif

// S17: PTAG dst/bin direct (hot free without kind/owner decode)
// Requires HZ3_SMALL_V2_PTAG_ENABLE=1
#ifndef HZ3_PTAG_DSTBIN_ENABLE
#define HZ3_PTAG_DSTBIN_ENABLE 0
#endif

// S18-1: PTAG dst/bin fast lookup (range check + tag load in one helper)
#ifndef HZ3_PTAG_DSTBIN_FASTLOOKUP
#define HZ3_PTAG_DSTBIN_FASTLOOKUP 0
#endif

// S18-2: PTAG dst/bin flat index (tag32 == flat+1, no decode/stride)
#ifndef HZ3_PTAG_DSTBIN_FLAT
#define HZ3_PTAG_DSTBIN_FLAT 0
#endif

#if HZ3_SUB4K_ENABLE
#if !HZ3_PTAG_DSTBIN_ENABLE
#error "HZ3_SUB4K_ENABLE requires HZ3_PTAG_DSTBIN_ENABLE=1"
#endif
#if !HZ3_SEG_SELF_DESC_ENABLE
#error "HZ3_SUB4K_ENABLE requires HZ3_SEG_SELF_DESC_ENABLE=1"
#endif
#endif

// S21: PTAG32-first usable_size/realloc (bin->size via PTAG32)
#ifndef HZ3_USABLE_SIZE_PTAG32
#define HZ3_USABLE_SIZE_PTAG32 0
#endif

#ifndef HZ3_REALLOC_PTAG32
#define HZ3_REALLOC_PTAG32 0
#endif

// S17: PTAG dst/bin stats (slow/event only)
#ifndef HZ3_PTAG_DSTBIN_STATS
#define HZ3_PTAG_DSTBIN_STATS 0
#endif

// S19-1: PTAG32 THP / TLB hint (init-only, hot 0 instructions)
// Applies MADV_HUGEPAGE to the PTAG32 table mapping when available.
#ifndef HZ3_PTAG32_HUGEPAGE
#define HZ3_PTAG32_HUGEPAGE 0
#endif

// S20-1: Prefetch PTAG32 entry after in-range check (hot adds 1 prefetch op).
// Intended to be used with HZ3_PTAG_DSTBIN_FASTLOOKUP=1.
#ifndef HZ3_PTAG32_PREFETCH
#define HZ3_PTAG32_PREFETCH 0
#endif

// S28-5: PTAG32 lookup hit-path optimization (no in_range store on hit)
// When 1, free hot path uses hz3_pagetag32_lookup_hit_fast() which skips
// the in_range out-param write. Miss path does separate range check.
// Note:
// - This is a conditional KEEP: dist=app/uniform improves, tiny is neutral.
// - Keep the header default conservative (0). The hz3 lane enables it via
//   `hakozuna/hz3/Makefile` (HZ3_LDPRELOAD_DEFS) to avoid affecting other builds.
#ifndef HZ3_PTAG32_NOINRANGE
#define HZ3_PTAG32_NOINRANGE 0
#endif

// S24: Budgeted remote bank flush (round-robin, event-only)
// Number of bins to scan per hz3_alloc_slow() call.
#ifndef HZ3_DSTBIN_FLUSH_BUDGET_BINS
#define HZ3_DSTBIN_FLUSH_BUDGET_BINS 32
#endif

// S24-2: Remote hint to skip flush when no remote free occurred
// GO: dist=app +3.4%, uniform no regression (2026-01-02)
#ifndef HZ3_DSTBIN_REMOTE_HINT_ENABLE
#define HZ3_DSTBIN_REMOTE_HINT_ENABLE 1
#endif

// S14: Large allocation cache (mmap reuse)
// When enabled, hz3_large_free() caches mappings instead of munmap
#ifndef HZ3_LARGE_CACHE_ENABLE
#define HZ3_LARGE_CACHE_ENABLE 1
#endif

// S14: Maximum bytes to cache (default 512MiB)
#ifndef HZ3_LARGE_CACHE_MAX_BYTES
#define HZ3_LARGE_CACHE_MAX_BYTES (512u << 20)
#endif

// S14: Maximum number of cached nodes (default 64)
#ifndef HZ3_LARGE_CACHE_MAX_NODES
#define HZ3_LARGE_CACHE_MAX_NODES 64
#endif

// S15: Hz3Stats dump (atexit dump of refill_calls, central_pop_miss, etc.)
// For triage: enable to see slow path call counts per sc
#ifndef HZ3_STATS_DUMP
#define HZ3_STATS_DUMP 0
#endif

// S28: Tiny (small v2) slow path stats (event-only, atexit dump)
// For triage: measure slow_rate to determine if bottleneck is hot or supply
#ifndef HZ3_TINY_STATS
#define HZ3_TINY_STATS 0
#endif

// S28-2A: Bank row base cache (TLS caches &bank[my_shard][0] for faster bin access)
// Reduces dependency chain in hz3_tcache_get_small_bin() / hz3_tcache_get_bin()
#ifndef HZ3_TCACHE_BANK_ROW_CACHE
#define HZ3_TCACHE_BANK_ROW_CACHE 0
#endif

// S28-2B: Small bin nocount (hot path から count 更新を除去)
// alloc/free の hot path で bin->count++/-- を省略し store を削減
#ifndef HZ3_SMALL_BIN_NOCOUNT
#define HZ3_SMALL_BIN_NOCOUNT 0
#endif

// S28-2C: Local bins split (local を bank から分離)
// local alloc/free は small_bins[]/bins[] を使い、浅い TLS オフセットに
#ifndef HZ3_LOCAL_BINS_SPLIT
#define HZ3_LOCAL_BINS_SPLIT 0
#endif

// S32-1: TLS init check を malloc hot から除去（miss/slow 入口でのみ init）
// When 1: malloc hot hit では ensure_init() を呼ばず、miss/slow path の入口で ensure_init_slow()
// Note: free は引き続き ensure_init() を呼ぶ（init前のdst routing等の安全のため）
#ifndef HZ3_TCACHE_INIT_ON_MISS
#define HZ3_TCACHE_INIT_ON_MISS 0
#endif

// S16-2: PageTag layout v2 (0-based sc/owner encoding)
// When 1: sc/owner stored as 0-based (no +1), decode avoids -1 operations
// When 0: legacy encoding (sc+1, owner+1)
#ifndef HZ3_PTAG_LAYOUT_V2
#define HZ3_PTAG_LAYOUT_V2 0
#endif

// S16-2D: Split free fast/slow to reduce spills (A/B gate)
#ifndef HZ3_FREE_FASTPATH_SPLIT
#define HZ3_FREE_FASTPATH_SPLIT 0
#endif

// S26-2: Span carve for sc=6,7 (28KB, 32KB) - allocate larger span, carve into 4 objects
// Reduces segment_alloc_run() calls by 4x for these size classes
#ifndef HZ3_SPAN_CARVE_ENABLE
#define HZ3_SPAN_CARVE_ENABLE 0
#endif
