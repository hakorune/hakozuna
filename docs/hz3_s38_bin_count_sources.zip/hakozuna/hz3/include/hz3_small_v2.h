#pragma once

#include <stddef.h>
#include <stdint.h>

#include "hz3_config.h"
#include "hz3_small.h"
#include "hz3_tcache.h"
#include "hz3_types.h"

struct Hz3SegHdr;

// Task 3: page magic for fast small v2 detection (no seg_hdr read)
#define HZ3_PAGE_MAGIC 0x485A5032u  // "HZP2"

void* hz3_small_v2_alloc_slow(int sc);
void  hz3_small_v2_free_remote_slow(void* ptr, int sc, int owner);

static inline void* hz3_small_v2_alloc(size_t size) {
#if !HZ3_SMALL_V2_ENABLE || !HZ3_SEG_SELF_DESC_ENABLE
    (void)size;
    return NULL;
#else
    int sc = hz3_small_sc_from_size(size);
    if (sc < 0 || sc >= HZ3_SMALL_NUM_SC) {
        return NULL;
    }

#if !HZ3_TCACHE_INIT_ON_MISS
    hz3_tcache_ensure_init();
#endif
    // S32-1: When HZ3_TCACHE_INIT_ON_MISS=1, skip init here.
    // TLS is zero-initialized, so bin->head == NULL → miss → slow path → init there.
    Hz3Bin* bin = hz3_tcache_get_small_bin(sc);
    void* obj = hz3_small_bin_pop(bin);
    if (obj) {
        return obj;
    }
    return hz3_small_v2_alloc_slow(sc);
#endif
}
void  hz3_small_v2_free(void* ptr, const struct Hz3SegHdr* hdr);
size_t hz3_small_v2_usable_size(void* ptr);
void  hz3_small_v2_bin_flush(int sc, Hz3Bin* bin);
// S17: remote list push (event-only)
void  hz3_small_v2_push_remote_list(uint8_t owner, int sc, void* head, void* tail, uint32_t n);

// Task 3: Fast free using page_hdr only (no seg_hdr read)
// page_hdr is void* to hide internal Hz3SmallV2PageHdr type
void  hz3_small_v2_free_fast(void* ptr, void* page_hdr);

// P4: fast local free using tag-decoded (sc, owner) - no page_hdr read
static inline void hz3_small_v2_free_local_fast(void* ptr, int sc) {
    Hz3Bin* bin = hz3_tcache_get_small_bin(sc);
    hz3_small_bin_push(bin, ptr);
}

// S12-4C: Fast free using tag-decoded (sc, owner) - no page_hdr read
// Called from hot path when PTAG is enabled
static inline void hz3_small_v2_free_by_tag(void* ptr, int sc, int owner) {
#if !HZ3_SMALL_V2_ENABLE || !HZ3_SEG_SELF_DESC_ENABLE
    (void)ptr;
    (void)sc;
    (void)owner;
#else
    if (!ptr) {
        return;
    }
    if (sc < 0 || sc >= HZ3_SMALL_NUM_SC) {
        return;
    }

    hz3_tcache_ensure_init();
    if (__builtin_expect((uint8_t)owner == t_hz3_cache.my_shard, 1)) {
        hz3_small_v2_free_local_fast(ptr, sc);
        return;
    }
    hz3_small_v2_free_remote_slow(ptr, sc, owner);
#endif
}
