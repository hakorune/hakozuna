#pragma once

#include "hz3_types.h"
#include "hz3_sc.h"
#include "hz3_small.h"
#if HZ3_SUB4K_ENABLE
#include "hz3_sub4k.h"
#endif

// ============================================================================
// Intrusive linked list pointer operations (0-cost, debug-friendly)
// ============================================================================

// Get next pointer from object (intrusive list: next stored at obj[0])
static inline void* hz3_obj_get_next(void* obj) {
    return *(void**)obj;
}

// Set next pointer in object
static inline void hz3_obj_set_next(void* obj, void* next) {
    *(void**)obj = next;
}

// ============================================================================
// TLS Bin operations (push/pop)
// ============================================================================

// Push object to bin head (LIFO)
static inline void hz3_bin_push(Hz3Bin* bin, void* obj) {
    hz3_obj_set_next(obj, bin->head);
    bin->head = obj;
    bin->count++;
}

// Pop object from bin head (returns NULL if empty)
static inline void* hz3_bin_pop(Hz3Bin* bin) {
    void* obj = bin->head;
    if (obj) {
        bin->head = hz3_obj_get_next(obj);
        bin->count--;
    }
    return obj;
}

// Check if bin is empty
static inline int hz3_bin_is_empty(Hz3Bin* bin) {
    return bin->head == NULL;
}

// Convert unified bin index to usable size (bytes). Returns 0 if invalid.
static inline size_t hz3_bin_to_usable_size(uint16_t bin) {
    if (bin < HZ3_SMALL_NUM_SC) {
        return hz3_small_sc_to_size((int)bin);
    }
#if HZ3_SUB4K_ENABLE
    if (bin < HZ3_MEDIUM_BIN_BASE) {
        return hz3_sub4k_sc_to_size((int)(bin - HZ3_SUB4K_BIN_BASE));
    }
#endif
    if (bin < HZ3_BIN_TOTAL) {
        return hz3_sc_to_size((int)(bin - HZ3_MEDIUM_BIN_BASE));
    }
    return 0;
}

// ============================================================================
// TLS Cache
// ============================================================================

// Thread-local cache (defined in hz3_tcache.c)
extern __thread Hz3TCache t_hz3_cache;

// Ensure TLS cache is initialized (call before any bin access)
void hz3_tcache_ensure_init_slow(void);
static inline void hz3_tcache_ensure_init(void) {
    if (__builtin_expect(t_hz3_cache.initialized, 1)) {
        return;
    }
    hz3_tcache_ensure_init_slow();
}

// Get bin for size class (assumes initialized)
#if HZ3_PTAG_DSTBIN_ENABLE
static inline int hz3_bin_index_small(int sc) {
    return sc;
}

#if HZ3_SUB4K_ENABLE
static inline int hz3_bin_index_sub4k(int sc) {
    return HZ3_SUB4K_BIN_BASE + sc;
}
#endif

static inline int hz3_bin_index_medium(int sc) {
    return HZ3_MEDIUM_BIN_BASE + sc;
}

static inline Hz3Bin* hz3_tcache_get_bin(int sc) {
    return &t_hz3_cache.bank[t_hz3_cache.my_shard][hz3_bin_index_medium(sc)];
}

static inline Hz3Bin* hz3_tcache_get_small_bin(int sc) {
    return &t_hz3_cache.bank[t_hz3_cache.my_shard][hz3_bin_index_small(sc)];
}

#if HZ3_SUB4K_ENABLE
static inline Hz3Bin* hz3_tcache_get_sub4k_bin(int sc) {
    return &t_hz3_cache.bank[t_hz3_cache.my_shard][hz3_bin_index_sub4k(sc)];
}
#endif

static inline Hz3Bin* hz3_tcache_get_bank_bin(uint8_t dst, int bin) {
    return &t_hz3_cache.bank[dst][bin];
}

#if HZ3_PTAG_DSTBIN_FLAT
static inline Hz3Bin* hz3_tcache_get_bank_bin_flat(uint32_t flat) {
    return &t_hz3_cache.bank[0][0] + flat;
}
#endif
#else
static inline Hz3Bin* hz3_tcache_get_bin(int sc) {
    return &t_hz3_cache.bins[sc];
}

// Get small bin for size class (assumes initialized)
static inline Hz3Bin* hz3_tcache_get_small_bin(int sc) {
    return &t_hz3_cache.small_bins[sc];
}
#endif

// ============================================================================
// Slow path functions (implemented in hz3_tcache.c)
// ============================================================================

// Allocate from slow path (called when bin is empty)
void* hz3_alloc_slow(int sc);

// ============================================================================
// Day 4: Outbox operations (implemented in hz3_tcache.c)
// ============================================================================

// Push object to outbox (flushes automatically when full)
void hz3_outbox_push(uint8_t owner, int sc, void* obj);

// Flush outbox to owner's inbox
void hz3_outbox_flush(uint8_t owner, int sc);

#if HZ3_PTAG_DSTBIN_ENABLE
// Flush remote banks to owner inbox/central (event-only)
void hz3_dstbin_flush_remote(void);
#endif
