#pragma once

#include <stdint.h>

#include "hz3_types.h"

#define HZ3_SEG_HDR_MAGIC 0x485a335345474844ULL  // "HZ3SEGH"
#define HZ3_SEG_KIND_SMALL 1u

typedef struct Hz3SegHdr {
    uint64_t magic;
    uint8_t  kind;
    uint8_t  owner;
    uint16_t reserved;
    uint32_t flags;
    uint16_t free_pages;
    uint16_t reserved2;
    uint32_t reserved3;
    uint64_t free_bits[HZ3_BITMAP_WORDS];
} Hz3SegHdr;

// ptr -> segment header (self-describing); returns NULL if not hz3
Hz3SegHdr* hz3_seg_from_ptr(const void* ptr);

// Allocate a small segment inside arena and return its header
Hz3SegHdr* hz3_seg_alloc_small(uint8_t owner);
