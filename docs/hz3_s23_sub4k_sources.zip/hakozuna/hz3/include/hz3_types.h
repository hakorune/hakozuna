#pragma once

#include <stddef.h>
#include <stdint.h>
#include <stdatomic.h>
#include "hz3_config.h"

// Segment constants
#define HZ3_SEG_SIZE      (2u << 20)  // 2MB
#define HZ3_SEG_SHIFT     21
#define HZ3_PAGE_SIZE     4096
#define HZ3_PAGE_SHIFT    12
#define HZ3_PAGES_PER_SEG (HZ3_SEG_SIZE >> HZ3_PAGE_SHIFT)  // 512
#define HZ3_NUM_SC        8   // size classes: 4KB-32KB
#define HZ3_SMALL_MIN_SIZE 16
#define HZ3_SMALL_MAX_SIZE 2048
#define HZ3_SMALL_ALIGN    16
#define HZ3_SMALL_NUM_SC   (HZ3_SMALL_MAX_SIZE / HZ3_SMALL_ALIGN)
#define HZ3_SUB4K_MIN_SIZE (HZ3_SMALL_MAX_SIZE + 1u)
#define HZ3_SUB4K_MAX_SIZE (HZ3_PAGE_SIZE - 1u)
#define HZ3_NUM_SHARDS    8   // number of shards
#define HZ3_BITMAP_WORDS  (HZ3_PAGES_PER_SEG / 64)  // 512/64 = 8
#if HZ3_SUB4K_ENABLE
#define HZ3_SUB4K_BIN_BASE HZ3_SMALL_NUM_SC
#define HZ3_MEDIUM_BIN_BASE (HZ3_SMALL_NUM_SC + HZ3_SUB4K_NUM_SC)
#define HZ3_BIN_TOTAL     (HZ3_MEDIUM_BIN_BASE + HZ3_NUM_SC)
#else
#define HZ3_SUB4K_BIN_BASE HZ3_SMALL_NUM_SC
#define HZ3_MEDIUM_BIN_BASE HZ3_SMALL_NUM_SC
#define HZ3_BIN_TOTAL     (HZ3_SMALL_NUM_SC + HZ3_NUM_SC)
#endif

// Forward declaration
struct Hz3SegMeta;
struct Hz3SegHdr;

// Segment metadata (separate allocation, not in segment)
typedef struct Hz3SegMeta {
    uint8_t  owner;                        // shard id
    uint16_t sc_tag[HZ3_PAGES_PER_SEG];    // page_idx -> tag (0=none)
    // munmap tracking
    void*    reserve_base;
    size_t   reserve_size;
    // Day 3: run tracking
    void*    seg_base;                     // segment base address
    uint16_t free_pages;                   // number of free pages
    uint64_t free_bits[HZ3_BITMAP_WORDS];  // bitmap: 1=free, 0=used
    // S12-5A: arena slot index for hz3_arena_free()
    uint32_t arena_idx;
} Hz3SegMeta;

// TLS bin (single-linked list)
typedef struct {
    void*    head;
    uint16_t count;
} Hz3Bin;

// Hard cap constants (hot path uses only these, learning layer unused in v1)
#define HZ3_BIN_HARD_CAP    16
#define HZ3_DRAIN_TRIGGER   20

// S15-1: sc=0 (4KB) needs thicker bin for mixed workloads
// (2049-4095 requests round up to 4KB, increasing sc=0 demand)
#ifndef HZ3_BIN_CAP_SC0
#define HZ3_BIN_CAP_SC0     32
#endif


// Day 5: Refill batch size per size class (compile-time constant)
// Larger batches for smaller objects to amortize slow path overhead
static const uint8_t HZ3_REFILL_BATCH[8] = {
    12, 8, 4, 4, 4, 2, 2, 2
};

// Day 4: Outbox for remote free
#define HZ3_OUTBOX_SIZE     32

typedef struct {
    void*   slots[HZ3_OUTBOX_SIZE];
    uint8_t count;
} Hz3OutboxBin;

// Day 6: Knobs (TLS snapshot of global knobs)
typedef struct {
    uint8_t refill_batch[HZ3_NUM_SC];
    uint8_t bin_target[HZ3_NUM_SC];
    uint8_t outbox_flush_n;
} Hz3Knobs;

// Day 6: Stats for learning (updated only in slow/event path)
typedef struct {
    uint32_t refill_calls[HZ3_NUM_SC];
    uint32_t inbox_drained_objs[HZ3_NUM_SC];
    uint32_t central_pop_hit[HZ3_NUM_SC];
    uint32_t central_pop_miss[HZ3_NUM_SC];
    uint32_t segment_new_count;
    uint32_t bin_trim_excess[HZ3_NUM_SC];
#if HZ3_S12_V2_STATS
    // S12-3C triage: v2 detection counters (TLS, no atomics in hot path)
    uint64_t s12_v2_seg_from_ptr_calls;
    uint64_t s12_v2_seg_from_ptr_hit;
    uint64_t s12_v2_seg_from_ptr_miss;
    uint64_t s12_v2_small_v2_enter;
#endif
#if HZ3_V2_ONLY_STATS
    // S12-8: v2-only PTAG coverage (TLS, no atomics in hot path)
    uint64_t v2_only_tag_load;
    uint64_t v2_only_tag_zero;
    uint64_t v2_only_tag_nonzero;
    uint64_t v2_only_dispatch_v2;
    uint64_t v2_only_dispatch_v1;
#endif
} Hz3Stats;

// Thread cache (TLS)
typedef struct {
    Hz3Bin  bins[HZ3_NUM_SC];
    Hz3Bin  small_bins[HZ3_SMALL_NUM_SC];
#if HZ3_PTAG_DSTBIN_ENABLE
    Hz3Bin  bank[HZ3_NUM_SHARDS][HZ3_BIN_TOTAL];
#if HZ3_PTAG_DSTBIN_TLS
    void*   arena_base;            // TLS snapshot of arena base
    _Atomic(uint32_t)* page_tag32;  // TLS snapshot of PTAG32 base
#endif
#endif
    uint8_t my_shard;
    uint8_t initialized;
    // Day 3: current segment for slow alloc
    struct Hz3SegMeta* current_seg;
    // Small v2: current segment for small pages
    struct Hz3SegHdr* small_current_seg;
    // Day 4: outbox[owner][sc] for remote free
    Hz3OutboxBin outbox[HZ3_NUM_SHARDS][HZ3_NUM_SC];
    // Day 6: knobs snapshot (copied from g_knobs at epoch)
    Hz3Knobs knobs;
    uint32_t knobs_ver;
    // Day 6: stats for learning
    Hz3Stats stats;
} Hz3TCache;
