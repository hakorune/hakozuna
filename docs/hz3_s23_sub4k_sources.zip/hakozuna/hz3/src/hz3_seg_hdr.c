#define _GNU_SOURCE

#include "hz3_seg_hdr.h"

#include "hz3_arena.h"
#include "hz3_config.h"
#include "hz3_segment.h"
#include "hz3_tcache.h"

#include <stdlib.h>

static inline void hz3_seg_hdr_init_bits(Hz3SegHdr* hdr) {
    for (size_t i = 0; i < HZ3_BITMAP_WORDS; i++) {
        hdr->free_bits[i] = UINT64_MAX;
    }
    hz3_bitmap_mark_used(hdr->free_bits, 0, 1);
    hdr->free_pages = (uint16_t)(HZ3_PAGES_PER_SEG - 1);
}

Hz3SegHdr* hz3_seg_from_ptr(const void* ptr) {
#if !HZ3_SEG_SELF_DESC_ENABLE
    (void)ptr;
    return NULL;
#else
#if HZ3_S12_V2_STATS
    if (t_hz3_cache.initialized) {
        t_hz3_cache.stats.s12_v2_seg_from_ptr_calls++;
    }
#endif

    uint32_t idx;
    void* base;
    // Use fast path: no pthread_once, returns 0 if arena not initialized
    if (!hz3_arena_contains_fast(ptr, &idx, &base)) {
#if HZ3_S12_V2_STATS
        if (t_hz3_cache.initialized) {
            t_hz3_cache.stats.s12_v2_seg_from_ptr_miss++;
        }
#endif
        return NULL;
    }

    Hz3SegHdr* hdr = (Hz3SegHdr*)base;
    if (hdr->magic != HZ3_SEG_HDR_MAGIC) {
#if HZ3_SMALL_V2_FAILFAST
        abort();
#endif
#if HZ3_S12_V2_STATS
        if (t_hz3_cache.initialized) {
            t_hz3_cache.stats.s12_v2_seg_from_ptr_miss++;
        }
#endif
        return NULL;
    }
#if HZ3_S12_V2_STATS
    if (t_hz3_cache.initialized) {
        t_hz3_cache.stats.s12_v2_seg_from_ptr_hit++;
    }
#endif
    return hdr;
#endif
}

Hz3SegHdr* hz3_seg_alloc_small(uint8_t owner) {
#if !HZ3_SEG_SELF_DESC_ENABLE
    (void)owner;
    return NULL;
#else
    uint32_t idx = 0;
    void* base = hz3_arena_alloc(&idx);
    if (!base) {
        return NULL;
    }

    Hz3SegHdr* hdr = (Hz3SegHdr*)base;
    hdr->magic = HZ3_SEG_HDR_MAGIC;
    hdr->kind = HZ3_SEG_KIND_SMALL;
    hdr->owner = owner;
    hdr->reserved = 0;
    hdr->flags = 0;
    hdr->reserved2 = 0;
    hdr->reserved3 = 0;

    hz3_seg_hdr_init_bits(hdr);
    return hdr;
#endif
}
