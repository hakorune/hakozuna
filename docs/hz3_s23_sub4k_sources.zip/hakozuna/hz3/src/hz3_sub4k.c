#include "hz3_sub4k.h"

#include "hz3_arena.h"
#include "hz3_seg_hdr.h"
#include "hz3_segment.h"
#include "hz3_tcache.h"

#include <pthread.h>

#if !HZ3_SUB4K_ENABLE
int hz3_sub4k_sc_from_size(size_t size) {
    (void)size;
    return -1;
}

size_t hz3_sub4k_sc_to_size(int sc) {
    (void)sc;
    return 0;
}

void* hz3_sub4k_alloc(size_t size) {
    (void)size;
    return NULL;
}

void hz3_sub4k_bin_flush(int sc, Hz3Bin* bin) {
    (void)sc;
    (void)bin;
}

void hz3_sub4k_push_remote_list(uint8_t owner, int sc, void* head, void* tail, uint32_t n) {
    (void)owner;
    (void)sc;
    (void)head;
    (void)tail;
    (void)n;
}

#else

#define HZ3_SUB4K_REFILL_BATCH 8

static const uint16_t g_hz3_sub4k_sizes[HZ3_SUB4K_NUM_SC] = {
    2304, 2816, 3328, 3840
};
_Static_assert(HZ3_SUB4K_NUM_SC == 4, "update g_hz3_sub4k_sizes for new class count");

int hz3_sub4k_sc_from_size(size_t size) {
    if (size <= HZ3_SMALL_MAX_SIZE || size > HZ3_SUB4K_MAX_SIZE) {
        return -1;
    }
    size_t aligned = (size + (HZ3_SMALL_ALIGN - 1u)) & ~(size_t)(HZ3_SMALL_ALIGN - 1u);
    if (aligned <= g_hz3_sub4k_sizes[0]) return 0;
    if (aligned <= g_hz3_sub4k_sizes[1]) return 1;
    if (aligned <= g_hz3_sub4k_sizes[2]) return 2;
    if (aligned <= g_hz3_sub4k_sizes[3]) return 3;
    return -1;
}

size_t hz3_sub4k_sc_to_size(int sc) {
    if (sc < 0 || sc >= HZ3_SUB4K_NUM_SC) {
        return 0;
    }
    return (size_t)g_hz3_sub4k_sizes[sc];
}

typedef struct {
    pthread_mutex_t lock;
    void* head;
    uint32_t count;
} Hz3Sub4kCentralBin;

static pthread_once_t g_hz3_sub4k_central_once = PTHREAD_ONCE_INIT;
static Hz3Sub4kCentralBin g_hz3_sub4k_central[HZ3_NUM_SHARDS][HZ3_SUB4K_NUM_SC];

static void hz3_sub4k_central_do_init(void) {
    for (int shard = 0; shard < HZ3_NUM_SHARDS; shard++) {
        for (int sc = 0; sc < HZ3_SUB4K_NUM_SC; sc++) {
            Hz3Sub4kCentralBin* bin = &g_hz3_sub4k_central[shard][sc];
            pthread_mutex_init(&bin->lock, NULL);
            bin->head = NULL;
            bin->count = 0;
        }
    }
}

static inline void hz3_sub4k_central_init(void) {
    pthread_once(&g_hz3_sub4k_central_once, hz3_sub4k_central_do_init);
}

static void hz3_sub4k_central_push_list(uint8_t shard, int sc, void* head, void* tail, uint32_t n) {
    if (!head || !tail || n == 0) {
        return;
    }
    Hz3Sub4kCentralBin* bin = &g_hz3_sub4k_central[shard][sc];
    pthread_mutex_lock(&bin->lock);
    hz3_obj_set_next(tail, bin->head);
    bin->head = head;
    bin->count += n;
    pthread_mutex_unlock(&bin->lock);
}

static int hz3_sub4k_central_pop_batch(uint8_t shard, int sc, void** out, int want) {
    Hz3Sub4kCentralBin* bin = &g_hz3_sub4k_central[shard][sc];
    pthread_mutex_lock(&bin->lock);
    int got = 0;
    while (got < want && bin->head) {
        void* cur = bin->head;
        void* next = hz3_obj_get_next(cur);
        out[got++] = cur;
        bin->head = next;
        bin->count--;
    }
    pthread_mutex_unlock(&bin->lock);
    return got;
}

static void* hz3_sub4k_alloc_run(int sc) {
    (void)sc;
    Hz3SegHdr* hdr = t_hz3_cache.small_current_seg;
    if (!hdr || hdr->free_pages < 2) {
        hdr = hz3_seg_alloc_small(t_hz3_cache.my_shard);
        if (!hdr) {
            return NULL;
        }
        t_hz3_cache.small_current_seg = hdr;
    }

    int start_page = hz3_bitmap_find_free(hdr->free_bits, 2);
    if (start_page < 0) {
        hdr = hz3_seg_alloc_small(t_hz3_cache.my_shard);
        if (!hdr) {
            return NULL;
        }
        t_hz3_cache.small_current_seg = hdr;
        start_page = hz3_bitmap_find_free(hdr->free_bits, 2);
        if (start_page < 0) {
            return NULL;
        }
    }

    hz3_bitmap_mark_used(hdr->free_bits, (size_t)start_page, 2);
    if (hdr->free_pages >= 2) {
        hdr->free_pages -= 2;
    } else {
        hdr->free_pages = 0;
    }

    char* run_base = (char*)hdr + ((size_t)start_page << HZ3_PAGE_SHIFT);

    uint32_t page_idx;
    if (g_hz3_page_tag32 && hz3_arena_page_index_fast(run_base, &page_idx)) {
        int bin = hz3_bin_index_sub4k(sc);
        uint32_t tag32 = hz3_pagetag32_encode(bin, (int)hdr->owner);
        hz3_pagetag32_store(page_idx, tag32);
        hz3_pagetag32_store(page_idx + 1u, tag32);
    }

    return run_base;
}

static void hz3_sub4k_fill_bin(Hz3Bin* bin, int sc, void* run_base) {
    size_t obj_size = hz3_sub4k_sc_to_size(sc);
    size_t run_bytes = HZ3_PAGE_SIZE * 2u;
    size_t count = run_bytes / obj_size;
    if (count == 0) {
        return;
    }

    char* cur = (char*)run_base;
    for (size_t i = 0; i + 1 < count; i++) {
        hz3_obj_set_next(cur, cur + obj_size);
        cur += obj_size;
    }
    hz3_obj_set_next(cur, bin->head);
    bin->head = run_base;
    bin->count += (uint16_t)count;
}

void* hz3_sub4k_alloc(size_t size) {
    int sc = hz3_sub4k_sc_from_size(size);
    if (sc < 0 || sc >= HZ3_SUB4K_NUM_SC) {
        return NULL;
    }

    hz3_tcache_ensure_init();
    Hz3Bin* bin = hz3_tcache_get_sub4k_bin(sc);
    void* obj = hz3_bin_pop(bin);
    if (obj) {
        return obj;
    }

    hz3_sub4k_central_init();
    void* batch[HZ3_SUB4K_REFILL_BATCH];
    int got = hz3_sub4k_central_pop_batch(t_hz3_cache.my_shard, sc, batch, HZ3_SUB4K_REFILL_BATCH);
    if (got > 0) {
        for (int i = 1; i < got; i++) {
            hz3_bin_push(bin, batch[i]);
        }
        return batch[0];
    }

    void* run = hz3_sub4k_alloc_run(sc);
    if (!run) {
        return NULL;
    }

    hz3_sub4k_fill_bin(bin, sc, run);
    return hz3_bin_pop(bin);
}

void hz3_sub4k_bin_flush(int sc, Hz3Bin* bin) {
    if (!bin || !bin->head || bin->count == 0) {
        return;
    }
    if (sc < 0 || sc >= HZ3_SUB4K_NUM_SC) {
        return;
    }

    hz3_sub4k_central_init();

    void* head = bin->head;
    void* tail = head;
    uint32_t n = 1;

    void* cur = hz3_obj_get_next(head);
    while (cur) {
        tail = cur;
        n++;
        cur = hz3_obj_get_next(cur);
    }

    hz3_sub4k_central_push_list(t_hz3_cache.my_shard, sc, head, tail, n);
    bin->head = NULL;
    bin->count = 0;
}

void hz3_sub4k_push_remote_list(uint8_t owner, int sc, void* head, void* tail, uint32_t n) {
    if (!head || !tail || n == 0) {
        return;
    }
    if (sc < 0 || sc >= HZ3_SUB4K_NUM_SC) {
        return;
    }
    hz3_sub4k_central_init();
    hz3_sub4k_central_push_list(owner, sc, head, tail, n);
}

#endif
