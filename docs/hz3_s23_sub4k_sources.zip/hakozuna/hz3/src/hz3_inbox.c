#define _GNU_SOURCE

#include "hz3_inbox.h"
#include "hz3_tcache.h"
#include "hz3_central.h"

#include <string.h>
#include <pthread.h>

// Global inbox pool (zero-initialized)
Hz3Inbox g_hz3_inbox[HZ3_NUM_SHARDS][HZ3_NUM_SC];

// Day 5: pthread_once for thread-safe initialization
static pthread_once_t g_hz3_inbox_once = PTHREAD_ONCE_INIT;

static void hz3_inbox_do_init(void) {
    for (int shard = 0; shard < HZ3_NUM_SHARDS; shard++) {
        for (int sc = 0; sc < HZ3_NUM_SC; sc++) {
            Hz3Inbox* inbox = &g_hz3_inbox[shard][sc];
            atomic_store_explicit(&inbox->head, NULL, memory_order_relaxed);
            atomic_store_explicit(&inbox->count, 0, memory_order_relaxed);
        }
    }
}

void hz3_inbox_init(void) {
    pthread_once(&g_hz3_inbox_once, hz3_inbox_do_init);
}

void hz3_inbox_push_list(uint8_t owner, int sc, void* head, void* tail, uint32_t n) {
    if (owner >= HZ3_NUM_SHARDS) return;
    if (sc < 0 || sc >= HZ3_NUM_SC) return;
    if (!head || !tail) return;

    Hz3Inbox* inbox = &g_hz3_inbox[owner][sc];

    // CAS loop to push list atomically
    void* old_head;
    do {
        old_head = atomic_load_explicit(&inbox->head, memory_order_acquire);
        hz3_obj_set_next(tail, old_head);
    } while (!atomic_compare_exchange_weak_explicit(
        &inbox->head, &old_head, head,
        memory_order_release, memory_order_relaxed));

    atomic_fetch_add_explicit(&inbox->count, n, memory_order_relaxed);
}

void hz3_inbox_push_remaining(uint8_t shard, int sc, void* obj) {
    if (shard >= HZ3_NUM_SHARDS) return;
    if (sc < 0 || sc >= HZ3_NUM_SC) return;
    if (!obj) return;

    // Find tail and count
    void* head = obj;
    void* tail = obj;
    uint32_t n = 1;
    void* next = hz3_obj_get_next(obj);
    while (next) {
        tail = next;
        n++;
        next = hz3_obj_get_next(next);
    }

    hz3_inbox_push_list(shard, sc, head, tail, n);
}

void* hz3_inbox_drain(uint8_t shard, int sc, Hz3Bin* bin) {
    if (shard >= HZ3_NUM_SHARDS) return NULL;
    if (sc < 0 || sc >= HZ3_NUM_SC) return NULL;
    if (!bin) return NULL;

    Hz3Inbox* inbox = &g_hz3_inbox[shard][sc];

    // Fast path: empty check without RMW
    void* head = atomic_load_explicit(&inbox->head, memory_order_acquire);
    if (!head) return NULL;

    // Swap entire list (atomic_exchange is cheaper than CAS loop for drain)
    head = atomic_exchange_explicit(&inbox->head, NULL, memory_order_acq_rel);
    if (!head) return NULL;

    // Reset count (approximate)
    atomic_store_explicit(&inbox->count, 0, memory_order_relaxed);

    // First object is returned immediately for use
    void* first = head;
    void* obj = hz3_obj_get_next(head);

    // Day 5: Build overflow list for central (don't re-push to inbox)
    void* overflow_head = NULL;
    void* overflow_tail = NULL;
    uint32_t overflow_n = 0;

    // Push to local bin, respecting HZ3_BIN_HARD_CAP
    while (obj) {
        void* next = hz3_obj_get_next(obj);
        if (bin->count < HZ3_BIN_HARD_CAP) {
            hz3_bin_push(bin, obj);
        } else {
            // Add to overflow list
            if (!overflow_head) {
                overflow_head = obj;
            } else {
                hz3_obj_set_next(overflow_tail, obj);
            }
            overflow_tail = obj;
            overflow_n++;
        }
        obj = next;
    }

    // Day 5: Send overflow to central (NOT back to inbox)
    if (overflow_head) {
        hz3_obj_set_next(overflow_tail, NULL);
        hz3_central_push_list(shard, sc, overflow_head, overflow_tail, overflow_n);
    }

    return first;
}

