#define _GNU_SOURCE

#include "hz3_segment.h"
#include "hz3_segmap.h"
#include "hz3_arena.h"

#include <stdint.h>
#include <sys/mman.h>
#include <string.h>

void* hz3_segment_alloc(void** out_reserve_base, size_t* out_reserve_size) {
    // Reserve 2x to guarantee alignment
    size_t reserve = HZ3_SEG_SIZE * 2;
    void* mem = mmap(NULL, reserve, PROT_READ | PROT_WRITE,
                     MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);
    if (mem == MAP_FAILED) {
        *out_reserve_base = NULL;
        *out_reserve_size = 0;
        return NULL;
    }

    // Align to 2MB boundary
    uintptr_t addr = (uintptr_t)mem;
    uintptr_t aligned_addr = (addr + HZ3_SEG_SIZE - 1) & ~((uintptr_t)HZ3_SEG_SIZE - 1);
    void* aligned = (void*)aligned_addr;

    // Trim excess (front and back)
    uintptr_t front = aligned_addr - addr;
    uintptr_t back = reserve - front - HZ3_SEG_SIZE;

    if (front > 0) {
        munmap(mem, front);
    }
    if (back > 0) {
        munmap((char*)aligned + HZ3_SEG_SIZE, back);
    }

    // After trim, reserve info is just the aligned segment
    *out_reserve_base = aligned;
    *out_reserve_size = HZ3_SEG_SIZE;

    return aligned;
}

// S12-5A: Updated to accept arena_idx for hz3_arena_free()
Hz3SegMeta* hz3_segment_init(void* base, uint8_t owner, void* reserve_base, size_t reserve_size, uint32_t arena_idx) {
    // Allocate SegMeta separately (not in segment, for cache locality separation)
    Hz3SegMeta* meta = mmap(NULL, sizeof(Hz3SegMeta), PROT_READ | PROT_WRITE,
                            MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);
    if (meta == MAP_FAILED) {
        return NULL;
    }

    meta->owner = owner;
    memset(meta->sc_tag, 0, sizeof(meta->sc_tag));
    meta->reserve_base = reserve_base;
    meta->reserve_size = reserve_size;
    meta->arena_idx = arena_idx;  // S12-5A: store arena slot index

    // Day 3: Initialize run tracking
    meta->seg_base = base;
    meta->free_pages = HZ3_PAGES_PER_SEG;
    // Set all bits to 1 (all pages free)
    for (size_t i = 0; i < HZ3_BITMAP_WORDS; i++) {
        meta->free_bits[i] = ~0ULL;
    }

    // Register in segmap
    hz3_segmap_set(base, meta);

    return meta;
}

void hz3_segment_free(void* base) {
    Hz3SegMeta* meta = hz3_segmap_get(base);
    if (!meta) return;

    // S12-5A: Get arena_idx before clearing
    uint32_t arena_idx = meta->arena_idx;

    // Clear segmap first
    hz3_segmap_clear(base);

    // Clear seg_base for safety
    meta->seg_base = NULL;

    // Then free memory
    void* reserve_base = meta->reserve_base;
    size_t reserve_size = meta->reserve_size;

    // Free meta
    munmap(meta, sizeof(Hz3SegMeta));

    // S12-5A: Free segment via arena (if arena_idx is valid)
    // UINT32_MAX indicates legacy allocation (not from arena)
    if (arena_idx != UINT32_MAX) {
#if HZ3_SMALL_V2_PTAG_ENABLE
        // Clear page tags first (before releasing arena slot)
        hz3_arena_clear_segment_tags(base);
#endif
        hz3_arena_free(arena_idx);
    } else if (reserve_base && reserve_size > 0) {
        // Legacy path: direct munmap
        munmap(reserve_base, reserve_size);
    }
}

// ============================================================================
// Run allocation (Day 3)
// ============================================================================

int hz3_segment_alloc_run(Hz3SegMeta* meta, size_t pages) {
    if (!meta || pages == 0 || pages > 8) {
        return -1;
    }
    if (meta->free_pages < pages) {
        return -1;
    }

    // Find contiguous free pages
    int start = hz3_bitmap_find_free(meta->free_bits, pages);
    if (start < 0) {
        return -1;
    }

    // Mark as used
    hz3_bitmap_mark_used(meta->free_bits, (size_t)start, pages);
    meta->free_pages -= (uint16_t)pages;

    return start;
}

void hz3_segment_free_run(Hz3SegMeta* meta, size_t start_page, size_t pages) {
    if (!meta || pages == 0 || pages > 8) {
        return;
    }
    if (start_page + pages > HZ3_PAGES_PER_SEG) {
        return;
    }

    // Mark as free
    hz3_bitmap_mark_free(meta->free_bits, start_page, pages);
    meta->free_pages += (uint16_t)pages;

    // Clear tags
    for (size_t i = 0; i < pages; i++) {
        meta->sc_tag[start_page + i] = 0;
    }
}

Hz3SegMeta* hz3_new_segment(uint8_t owner) {
    // S12-5A: Use arena allocation (same as v2)
    uint32_t arena_idx = 0;
    void* base = hz3_arena_alloc(&arena_idx);
    if (!base) {
        return NULL;
    }
    // reserve_base/size are not used for arena allocations
    // arena_idx is stored in meta for hz3_arena_free()
    return hz3_segment_init(base, owner, base, HZ3_SEG_SIZE, arena_idx);
}

