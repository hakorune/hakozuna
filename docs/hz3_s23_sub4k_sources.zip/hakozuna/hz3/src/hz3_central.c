#define _GNU_SOURCE

#include "hz3_central.h"
#include "hz3_tcache.h"

#include <string.h>

// Global central pool (zero-initialized)
Hz3CentralBin g_hz3_central[HZ3_NUM_SHARDS][HZ3_NUM_SC];

// Day 5: pthread_once for thread-safe initialization
static pthread_once_t g_hz3_central_once = PTHREAD_ONCE_INIT;

static void hz3_central_do_init(void) {
    for (int shard = 0; shard < HZ3_NUM_SHARDS; shard++) {
        for (int sc = 0; sc < HZ3_NUM_SC; sc++) {
            Hz3CentralBin* bin = &g_hz3_central[shard][sc];
            pthread_mutex_init(&bin->lock, NULL);
            bin->head = NULL;
            bin->count = 0;

        }
    }
}

void hz3_central_init(void) {
    pthread_once(&g_hz3_central_once, hz3_central_do_init);
}

void hz3_central_push(int shard, int sc, void* run) {
    if (shard < 0 || shard >= HZ3_NUM_SHARDS) return;
    if (sc < 0 || sc >= HZ3_NUM_SC) return;
    if (!run) return;

    Hz3CentralBin* bin = &g_hz3_central[shard][sc];

    pthread_mutex_lock(&bin->lock);

    // Intrusive list: store next at run[0]
    hz3_obj_set_next(run, bin->head);
    bin->head = run;
    bin->count++;

    pthread_mutex_unlock(&bin->lock);
}

void* hz3_central_pop(int shard, int sc) {
    if (shard < 0 || shard >= HZ3_NUM_SHARDS) return NULL;
    if (sc < 0 || sc >= HZ3_NUM_SC) return NULL;

    Hz3CentralBin* bin = &g_hz3_central[shard][sc];

    pthread_mutex_lock(&bin->lock);

    void* run = bin->head;
    if (run) {
        bin->head = hz3_obj_get_next(run);
        bin->count--;
    }

    pthread_mutex_unlock(&bin->lock);

    return run;
}

// ============================================================================
// Day 5: Batch API
// ============================================================================

// Push a linked list to central (head→...→tail in forward order)
// tail->next will be set to old head (caller doesn't need to set it)
void hz3_central_push_list(int shard, int sc, void* head, void* tail, uint32_t n) {
    if (shard < 0 || shard >= HZ3_NUM_SHARDS) return;
    if (sc < 0 || sc >= HZ3_NUM_SC) return;
    if (!head || !tail || n == 0) return;

    Hz3CentralBin* bin = &g_hz3_central[shard][sc];

    pthread_mutex_lock(&bin->lock);
    hz3_obj_set_next(tail, bin->head);  // tail->next = old head
    bin->head = head;
    bin->count += n;
    pthread_mutex_unlock(&bin->lock);
}

// Pop up to 'want' objects into out array (returns actual count)
int hz3_central_pop_batch(int shard, int sc, void** out, int want) {
    if (shard < 0 || shard >= HZ3_NUM_SHARDS) return 0;
    if (sc < 0 || sc >= HZ3_NUM_SC) return 0;
    if (!out || want <= 0) return 0;

    Hz3CentralBin* bin = &g_hz3_central[shard][sc];

    pthread_mutex_lock(&bin->lock);
    int got = 0;
    while (got < want && bin->head) {
        void* cur = bin->head;
        void* next = hz3_obj_get_next(cur);
        out[got++] = cur;
        bin->head = next;
        bin->count--;
    }
    pthread_mutex_unlock(&bin->lock);

    return got;
}

