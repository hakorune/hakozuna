# hz3: Build / Flags / SSOT Index（hz3専用）

目的:
- hz3（`hakozuna/hz3/`）の compile-time フラグとベンチ導線を、hakozuna本線と混線しない形で集約する。
- allocator 本体の挙動切替は **compile-time `-D`** に統一する（envノブ禁止）。

参照:
- hz3 入口: `hakozuna/docs/PHASE_HZ3_BOOTSTRAP.md`
- SSOT lane（全体）: `hakozuna/docs/SSOT_THREE_LANES.md`
- hz3 SSOT script（small/medium/mixed）: `hakozuna/hz3/scripts/run_bench_hz3_ssot.sh`
- hybrid（研究箱）: `hakozuna/docs/PHASE_HZ3_DAY8_HYBRID_LDPRELOAD.md`
- hz3 NO-GO summary（研究箱索引）: `hakozuna/hz3/docs/NO_GO_SUMMARY.md`
- Small v2 PageTagMap 設計（案）: `hakozuna/hz3/docs/PHASE_HZ3_S12_4_SMALL_V2_PAGETAGMAP_PLAN.md`
- S12-5 plan（PTAG を large に拡張して mixed を詰める）: `hakozuna/hz3/docs/PHASE_HZ3_S12_5_PTAG_EXTEND_TO_LARGE_PLAN.md`
- S12-6（tcache init inline）: `hakozuna/hz3/docs/PHASE_HZ3_S12_6_INLINE_TCACHE_INIT.md`
- S12-7（batch=12 + NO-GO記録）: `hakozuna/hz3/docs/PHASE_HZ3_S12_7_BATCH_TUNING_AND_NO_GO.md`
- S13（TransferCache+BatchChain 設計）: `hakozuna/hz3/docs/PHASE_HZ3_S13_TRANSFERCACHE_DESIGN.md`
- S13（TransferCache+BatchChain 指示書/Work Order）: `hakozuna/hz3/docs/PHASE_HZ3_S13_TRANSFERCACHE_WORK_ORDER.md`
- S14（hz3_large cache 指示書/Work Order）: `hakozuna/hz3/docs/PHASE_HZ3_S14_LARGE_CACHE_WORK_ORDER.md`
- S15（mixed gap triage 指示書/Work Order）: `hakozuna/hz3/docs/PHASE_HZ3_S15_MIXED_GAP_TRIAGE_WORK_ORDER.md`
- S15-1（bin_target tuning 結果）: `hakozuna/hz3/docs/PHASE_HZ3_S15_1_BIN_TARGET_TUNING_RESULTS.md`
- S15-3（mixed 命令数差 perf 結果）: `hakozuna/hz3/docs/PHASE_HZ3_S15_3_MIXED_INSN_GAP_PERF_RESULTS.md`
- S16（mixed 命令数削減 指示書/Work Order）: `hakozuna/hz3/docs/PHASE_HZ3_S16_MIXED_INSN_REDUCTION_WORK_ORDER.md`
- S16-2C（tag decode lifetime 分割）: `hakozuna/hz3/docs/PHASE_HZ3_S16_2C_TAG_DECODE_LIFETIME_WORK_ORDER.md`
- S16-2C（tag decode lifetime 分割 結果）: `hakozuna/hz3/docs/PHASE_HZ3_S16_2C_TAG_DECODE_LIFETIME_RESULTS.md`
- S16-2D（hz3_free fast path の形を変える）: `hakozuna/hz3/docs/PHASE_HZ3_S16_2D_FREE_FASTPATH_SHAPE_WORK_ORDER.md`
- S17（PTAG dst/bin direct）: `hakozuna/hz3/docs/PHASE_HZ3_S17_PTAG_DSTBIN_DIRECT_WORK_ORDER.md`
- S16 状態: 2C NO-GO → 2D 実行中

---

## 1) Build ターゲット

hz3 本体:
- `make -C hakozuna/hz3 all_ldpreload`
  - 出力: `./libhakozuna_hz3_ldpreload.so`

hybrid（研究箱）:
- `make -C hakozuna/hz3 all_hybrid_ldpreload`
  - 出力: `./libhakozuna_hybrid_ldpreload.so`

注意（安全デフォルトと Makefile 既定の差）:
- `hakozuna/hz3/include/hz3_config.h` のデフォルトは安全側（`HZ3_ENABLE=0` / `HZ3_SHIM_FORWARD_ONLY=1`）。
- ただし `make -C hakozuna/hz3 all_ldpreload` は Makefile 既定で `HZ3_LDPRELOAD_DEFS` を付ける（上書き可能）。
  - 現在の既定は SSOT 到達点として `Small v2 + self-desc + PTAG(v2 + v1-medium)` を ON にしている。

---

## 2) compile-time Flags（hz3_config.h）

すべて `-D` で指定する（allocator本体の env ノブは禁止）。

- `HZ3_ENABLE=0/1`
  - 0 のとき shim は RTLD_NEXT に forward（挙動変更なし）。
- `HZ3_SHIM_FORWARD_ONLY=0/1`
  - 1 のとき forward-only（安全用）。
- `HZ3_LEARN_ENABLE=0/1`
  - 学習層（event-only）。hot path から global knobs を読まない設計前提。
- `HZ3_SMALL_V2_ENABLE=0/1`
  - small v2（self-describing）ゲート。
  - `hakmem/hakozuna/hz3/include/hz3_config.h` のデフォルトは安全側（基本 OFF）。
  - ただし `make -C hakmem/hakozuna/hz3 all_ldpreload` は Makefile の `HZ3_LDPRELOAD_DEFS` 既定で ON（SSOT到達点プロファイル）。
- `HZ3_SEG_SELF_DESC_ENABLE=0/1`
  - self-describing segment header ゲート（small v2 と組み合わせる想定）。
- `HZ3_SMALL_V2_PTAG_ENABLE=0/1`
  - Small v2 の ptr→(kind,sc,owner) を `range check + 1 load` に寄せる PageTagMap を有効化する（S12-4）。
  - `HZ3_SMALL_V2_ENABLE=1` + `HZ3_SEG_SELF_DESC_ENABLE=1` と組み合わせて使う想定。
- `HZ3_PTAG_V1_ENABLE=0/1`
  - PageTagMap を large(4KB–32KB) にも拡張し、`hz3_free` の unified dispatch を成立させる（S12-5）。
  - 注意: `PTAG_KIND_V1_MEDIUM` の名称は “medium(4KB–32KB)” の歴史的ラベルで、`HZ3_SMALL_V1_ENABLE` とは別物。
- `HZ3_PTAG_DSTBIN_ENABLE=0/1`
  - S17: 32-bit PageTag（dst/bin直結）で `hz3_free` を `range check + tag load + push` に最短化する。
- `HZ3_PTAG_DSTBIN_TLS=0/1`
  - S18-1: arena base / PTAG base を TLS にスナップショット（hot の atomic load を削減）。
- `HZ3_PTAG_DSTBIN_ENABLE=0/1`
  - S17: PTAG を dst/bin 直結にし、`hz3_free` を “range check + tag load + push” に寄せる実験。
  - `HZ3_SMALL_V2_PTAG_ENABLE=1` が前提。NO-GO時は研究箱へ。
- `HZ3_PTAG_DSTBIN_STATS=0/1`
  - S17: dst/bin の flush 統計（event-only、hot には入れない）。
- `HZ3_PTAG_LAYOUT_V2=0/1`
  - S16-2: PageTag の encoding を 0-based（`sc/owner` を +1/-1 なし）にして decode 命令を減らす試行。
  - 期待通りに効かない（NO-GO）場合があるため、S16-2C（lifetime 分割）と併せて “spills削減” を狙う。
- `HZ3_FREE_FASTPATH_SPLIT=0/1`
  - S16-2D: `hz3_free` の fast/slow を分離して、prolog/spills を減らす試行。
  - 現状は NO-GO（`hakozuna/hz3/archive/research/s16_2d_free_fastpath_shape/README.md`）。
- `HZ3_PTAG_FAILFAST=0/1`
  - arena 内で `tag==0` など “ありえない状態” を検出したときの挙動（debug: abort / release: no-op）。
- `HZ3_SMALL_V2_FAILFAST=0/1`
  - debug 用の fail-fast（self-describing の整合性違反を即時露出）。
- `HZ3_V2_ONLY=0/1`
  - v2-only dispatch（segmap fallback を使わず、range check + PTAG だけで dispatch）。
  - 要件: `HZ3_SMALL_V2_PTAG_ENABLE=1` / `HZ3_SEG_SELF_DESC_ENABLE=1` / `HZ3_PTAG_V1_ENABLE=1`
- `HZ3_V2_ONLY_STATS=0/1`
  - v2-only coverage 観測用（TLS + atexit dump）。
  - **性能比較では必ず 0**（hot path にカウンタ増分が入るため）。
- `HZ3_LARGE_CACHE_ENABLE=0/1`
  - S14: `hz3_large` の mmap 再利用キャッシュ。
  - 既定値は `hakozuna/hz3/include/hz3_config.h` を参照（現在は 1）。
- `HZ3_LARGE_CACHE_MAX_BYTES=...`
  - S14: `hz3_large` のキャッシュ上限（バイト）。既定 512MiB。
- `HZ3_LARGE_CACHE_MAX_NODES=...`
  - S14: `hz3_large` のキャッシュ上限（ノード数）。既定 64。

---

## 3) SSOT-HZ3（hz3専用 lane）

用途:
- hz3 の small/medium/mixed を同一導線で SSOT 化する（混線防止）。

スクリプト:
- `hakozuna/hz3/scripts/run_bench_hz3_ssot.sh`

スクリプトの上書き変数（ベンチ導線用）:
- `RUNS` / `ITERS` / `WS` / `SKIP_BUILD`
- `HZ3_SO`（default: `./libhakozuna_hz3_ldpreload.so`）
- `BENCH_BIN`（default: `./hakozuna/out/bench_random_mixed_malloc_args`）
- `MIMALLOC_SO` / `TCMALLOC_SO`（任意。存在する場合のみ追加で比較）

`.env`:
- `hakozuna/hz3/scripts/run_bench_hz3_ssot.sh.env`（override-friendly）
  - ベンチの既定値を置く場所（allocator本体のノブには使わない）。

実行例:
```bash
RUNS=10 ITERS=20000000 WS=400 \
  ./hakozuna/hz3/scripts/run_bench_hz3_ssot.sh
```

---

## 4) Makefile 既定プロファイル（SSOT到達点）

`make -C hakmem/hakozuna/hz3 all_ldpreload` の既定（`HZ3_LDPRELOAD_DEFS`）は、SSOT到達点として次を ON にしている:
- `HZ3_ENABLE=1`
- `HZ3_SHIM_FORWARD_ONLY=0`
- `HZ3_SMALL_V2_ENABLE=1`
- `HZ3_SEG_SELF_DESC_ENABLE=1`
- `HZ3_SMALL_V2_PTAG_ENABLE=1`（S12-4）
- `HZ3_PTAG_V1_ENABLE=1`（S12-5: 4KB–32KB も PTAG で統一 dispatch）
- `HZ3_PTAG_DSTBIN_ENABLE=1`（S17: free を dst/bin 直結にして命令数削減）

既定を変えたい場合は、`HZ3_LDPRELOAD_DEFS` を上書きする（`CFLAGS` ではなく）:
```bash
make -C hakmem/hakozuna/hz3 clean all_ldpreload \
  HZ3_LDPRELOAD_DEFS='-DHZ3_ENABLE=1 -DHZ3_SHIM_FORWARD_ONLY=0'
```
