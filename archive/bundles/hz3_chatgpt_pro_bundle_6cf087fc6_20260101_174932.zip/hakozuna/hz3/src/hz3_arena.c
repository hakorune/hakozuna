#define _GNU_SOURCE

#include "hz3_arena.h"
#include "hz3_types.h"

#include <pthread.h>
#include <stdatomic.h>
#include <sys/mman.h>

#ifndef MAP_FIXED_NOREPLACE
#define MAP_FIXED_NOREPLACE MAP_FIXED
#endif

// ----------------------------------------------------------------------------
// Global atomic pointers for lock-free range check (S12-4)
// Published in do_init: end first (release), then base (release)
// Read order in hot path: base first (acquire), then end (relaxed)
// ----------------------------------------------------------------------------
_Atomic(void*) g_hz3_arena_base = NULL;
_Atomic(void*) g_hz3_arena_end = NULL;

#if HZ3_SMALL_V2_PTAG_ENABLE
// Page tag array: 0 = not ours, mmap'd in init
_Atomic(uint16_t)* g_hz3_page_tag = NULL;
#endif
#if HZ3_PTAG_DSTBIN_ENABLE
// S17: 32-bit PageTagMap (dst/bin direct)
_Atomic(uint32_t)* g_hz3_page_tag32 = NULL;
#endif

typedef struct {
    size_t size;
    uint32_t slots;
    _Atomic uint8_t* used;
} Hz3ArenaState;

static Hz3ArenaState g_hz3_arena;
static pthread_once_t g_hz3_arena_once = PTHREAD_ONCE_INIT;
static pthread_mutex_t g_hz3_arena_lock = PTHREAD_MUTEX_INITIALIZER;

static void hz3_arena_do_init(void) {
    g_hz3_arena.size = (size_t)HZ3_ARENA_SIZE;
    g_hz3_arena.slots = (uint32_t)(g_hz3_arena.size / HZ3_SEG_SIZE);

    void* base = mmap(NULL, g_hz3_arena.size, PROT_NONE,
                      MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);
    if (base == MAP_FAILED) {
        atomic_store_explicit(&g_hz3_arena_base, NULL, memory_order_release);
        g_hz3_arena.slots = 0;
        return;
    }

    size_t used_bytes = (size_t)g_hz3_arena.slots * sizeof(_Atomic uint8_t);
    void* used = mmap(NULL, used_bytes, PROT_READ | PROT_WRITE,
                      MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);
    if (used == MAP_FAILED) {
        munmap(base, g_hz3_arena.size);
        atomic_store_explicit(&g_hz3_arena_base, NULL, memory_order_release);
        g_hz3_arena.slots = 0;
        return;
    }

    g_hz3_arena.used = (_Atomic uint8_t*)used;
    for (uint32_t i = 0; i < g_hz3_arena.slots; i++) {
        atomic_store_explicit(&g_hz3_arena.used[i], 0, memory_order_relaxed);
    }

#if HZ3_SMALL_V2_PTAG_ENABLE
    // Allocate page tag array: 4GB / 4KB = 1M pages, 2 bytes each = 2MB
    size_t page_tag_bytes = HZ3_ARENA_MAX_PAGES * sizeof(_Atomic(uint16_t));
    void* page_tag = mmap(NULL, page_tag_bytes, PROT_READ | PROT_WRITE,
                          MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);
    if (page_tag == MAP_FAILED) {
        // Non-fatal: PTAG just won't work, fallback to v1 path
        g_hz3_page_tag = NULL;
    } else {
        g_hz3_page_tag = (_Atomic(uint16_t)*)page_tag;
        // mmap guarantees zero-filled, but be explicit for clarity
        // (no loop needed, mmap returns zeroed memory)
    }
#endif
#if HZ3_PTAG_DSTBIN_ENABLE
    // S17: Allocate 32-bit page tag array: 4GB / 4KB = 1M pages, 4 bytes each = 4MB
    size_t page_tag32_bytes = HZ3_ARENA_MAX_PAGES * sizeof(_Atomic(uint32_t));
    void* page_tag32 = mmap(NULL, page_tag32_bytes, PROT_READ | PROT_WRITE,
                            MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);
    if (page_tag32 == MAP_FAILED) {
        g_hz3_page_tag32 = NULL;
    } else {
        g_hz3_page_tag32 = (_Atomic(uint32_t)*)page_tag32;
    }
#endif

    // Compute arena end
    void* end = (char*)base + g_hz3_arena.size;

    // Atomic publish order: end FIRST, then base
    // This ensures readers who see base will also see a valid end
    atomic_store_explicit(&g_hz3_arena_end, end, memory_order_release);
    atomic_store_explicit(&g_hz3_arena_base, base, memory_order_release);
}

void hz3_arena_init_slow(void) {
    pthread_once(&g_hz3_arena_once, hz3_arena_do_init);
}

// Fast path: reads base atomically, returns 0 if not initialized.
// Does NOT call pthread_once (safe for free hot path).
// NOTE: This function reads used[] - for PageTagMap hot path, use
// hz3_arena_page_index_fast() instead (no used[] read).
int hz3_arena_contains_fast(const void* ptr, uint32_t* idx_out, void** base_out) {
    // Acquire load to synchronize with release store in do_init
    void* base_ptr = atomic_load_explicit(&g_hz3_arena_base, memory_order_acquire);
    if (!base_ptr) {
        return 0;  // Not initialized yet, false negative is OK
    }

    uintptr_t addr = (uintptr_t)ptr;
    uintptr_t base = (uintptr_t)base_ptr;
    if (addr < base || addr >= base + g_hz3_arena.size) {
        return 0;
    }

    uint32_t idx = (uint32_t)((addr - base) / HZ3_SEG_SIZE);
    if (idx >= g_hz3_arena.slots) {
        return 0;
    }

    if (!atomic_load_explicit(&g_hz3_arena.used[idx], memory_order_acquire)) {
        return 0;
    }

    if (idx_out) {
        *idx_out = idx;
    }
    if (base_out) {
        *base_out = (void*)(base + (uintptr_t)idx * HZ3_SEG_SIZE);
    }
    return 1;
}

// Legacy contains: calls init_slow first, then fast path.
int hz3_arena_contains(const void* ptr, uint32_t* idx_out, void** base_out) {
    hz3_arena_init_slow();
    return hz3_arena_contains_fast(ptr, idx_out, base_out);
}

#if HZ3_SMALL_V2_PTAG_ENABLE
// S12-4B: Clear page tags for a segment (all pages in 2MB segment)
// Called when segment is freed/recycled to prevent false positives
void hz3_arena_clear_segment_tags(void* seg_base) {
#if HZ3_PTAG_DSTBIN_ENABLE
    if (!g_hz3_page_tag && !g_hz3_page_tag32) {
        return;  // PTAG not initialized
    }
#else
    if (!g_hz3_page_tag) {
        return;  // PTAG not initialized
    }
#endif
    uint32_t page_idx;
    if (!hz3_arena_page_index_fast(seg_base, &page_idx)) {
        return;  // Not in arena
    }
    // Clear all pages in segment (2MB / 4KB = 512 pages)
    uint32_t pages_per_seg = HZ3_SEG_SIZE >> HZ3_ARENA_PAGE_SHIFT;
    for (uint32_t i = 0; i < pages_per_seg; i++) {
        if (g_hz3_page_tag) {
            hz3_pagetag_clear(page_idx + i);
        }
    }

#if HZ3_PTAG_DSTBIN_ENABLE
    if (g_hz3_page_tag32) {
        for (uint32_t i = 0; i < pages_per_seg; i++) {
            hz3_pagetag32_clear(page_idx + i);
        }
    }
#endif
}
#endif

void* hz3_arena_alloc(uint32_t* idx_out) {
    hz3_arena_init_slow();
    void* base_ptr = atomic_load_explicit(&g_hz3_arena_base, memory_order_acquire);
    if (!base_ptr) {
        return NULL;
    }

    pthread_mutex_lock(&g_hz3_arena_lock);
    for (uint32_t i = 0; i < g_hz3_arena.slots; i++) {
        if (atomic_load_explicit(&g_hz3_arena.used[i], memory_order_relaxed)) {
            continue;
        }
        void* addr = (char*)base_ptr + (size_t)i * HZ3_SEG_SIZE;
        void* mapped = mmap(addr, HZ3_SEG_SIZE, PROT_READ | PROT_WRITE,
                            MAP_PRIVATE | MAP_ANONYMOUS | MAP_FIXED,
                            -1, 0);
        if (mapped == MAP_FAILED) {
            continue;
        }
        atomic_store_explicit(&g_hz3_arena.used[i], 1, memory_order_release);
        pthread_mutex_unlock(&g_hz3_arena_lock);
        if (idx_out) {
            *idx_out = i;
        }
        return mapped;
    }
    pthread_mutex_unlock(&g_hz3_arena_lock);
    return NULL;
}

// S12-5A: Free a 2MB slot inside arena
// Uses madvise(MADV_DONTNEED) to release physical memory while keeping virtual address
void hz3_arena_free(uint32_t idx) {
    if (idx >= g_hz3_arena.slots) {
        return;
    }

    void* base_ptr = atomic_load_explicit(&g_hz3_arena_base, memory_order_acquire);
    if (!base_ptr) {
        return;
    }

    pthread_mutex_lock(&g_hz3_arena_lock);
    if (atomic_load_explicit(&g_hz3_arena.used[idx], memory_order_relaxed)) {
        void* addr = (char*)base_ptr + (size_t)idx * HZ3_SEG_SIZE;
        // madvise(MADV_DONTNEED): release physical memory, keep virtual address
        madvise(addr, HZ3_SEG_SIZE, MADV_DONTNEED);
        atomic_store_explicit(&g_hz3_arena.used[idx], 0, memory_order_release);
    }
    pthread_mutex_unlock(&g_hz3_arena_lock);
}
