#include "hz3_small_v2.h"

#include "hz3_arena.h"
#include "hz3_config.h"
#include "hz3_sc.h"
#include "hz3_seg_hdr.h"
#include "hz3_segment.h"
#include "hz3_tcache.h"
#include "hz3_small.h"

#include <pthread.h>
#include <stdint.h>

// Task 3: page_hdr に magic/owner/sc を集約して seg_hdr cold reads を除去
#define HZ3_SMALL_V2_PAGE_HDR_SIZE 16u
#define HZ3_PAGE_MAGIC 0x485A5032u  // "HZP2"
#define HZ3_SMALL_V2_REFILL_BATCH 32

// static_assert: sc を uint8_t で保持するため
_Static_assert(HZ3_SMALL_NUM_SC <= 255, "sc must fit in uint8_t");

typedef struct {
    uint32_t magic;    // HZ3_PAGE_MAGIC で small v2 ページを識別
    uint8_t  owner;    // seg_hdr から複製（ページ割当時）
    uint8_t  sc;       // size class
    uint16_t flags;    // reserved
    uint64_t reserved; // パディング（16B境界）
} Hz3SmallV2PageHdr;

typedef struct {
    pthread_mutex_t lock;
    void* head;
    uint32_t count;
} Hz3SmallV2CentralBin;

#if HZ3_SMALL_V2_ENABLE && HZ3_SEG_SELF_DESC_ENABLE
static pthread_once_t g_hz3_small_v2_central_once = PTHREAD_ONCE_INIT;
static Hz3SmallV2CentralBin g_hz3_small_v2_central[HZ3_NUM_SHARDS][HZ3_SMALL_NUM_SC];

static void hz3_small_v2_central_do_init(void) {
    for (int shard = 0; shard < HZ3_NUM_SHARDS; shard++) {
        for (int sc = 0; sc < HZ3_SMALL_NUM_SC; sc++) {
            Hz3SmallV2CentralBin* bin = &g_hz3_small_v2_central[shard][sc];
            pthread_mutex_init(&bin->lock, NULL);
            bin->head = NULL;
            bin->count = 0;
        }
    }
}

static inline void hz3_small_v2_central_init(void) {
    pthread_once(&g_hz3_small_v2_central_once, hz3_small_v2_central_do_init);
}

static void hz3_small_v2_central_push_list(uint8_t shard, int sc, void* head, void* tail, uint32_t n) {
    if (!head || !tail || n == 0) {
        return;
    }
    Hz3SmallV2CentralBin* bin = &g_hz3_small_v2_central[shard][sc];
    pthread_mutex_lock(&bin->lock);
    hz3_obj_set_next(tail, bin->head);
    bin->head = head;
    bin->count += n;
    pthread_mutex_unlock(&bin->lock);
}

void hz3_small_v2_push_remote_list(uint8_t owner, int sc, void* head, void* tail, uint32_t n) {
#if !HZ3_SMALL_V2_ENABLE || !HZ3_SEG_SELF_DESC_ENABLE
    (void)owner;
    (void)sc;
    (void)head;
    (void)tail;
    (void)n;
#else
    if (!head || !tail || n == 0) {
        return;
    }
    if (sc < 0 || sc >= HZ3_SMALL_NUM_SC) {
        return;
    }
    hz3_small_v2_central_init();
    hz3_small_v2_central_push_list(owner, sc, head, tail, n);
#endif
}

static int hz3_small_v2_central_pop_batch(uint8_t shard, int sc, void** out, int want) {
    Hz3SmallV2CentralBin* bin = &g_hz3_small_v2_central[shard][sc];
    pthread_mutex_lock(&bin->lock);
    int got = 0;
    while (got < want && bin->head) {
        void* cur = bin->head;
        void* next = hz3_obj_get_next(cur);
        out[got++] = cur;
        bin->head = next;
        bin->count--;
    }
    pthread_mutex_unlock(&bin->lock);
    return got;
}

static void* hz3_small_v2_alloc_page(int sc) {
    Hz3SegHdr* hdr = t_hz3_cache.small_current_seg;
    if (!hdr || hdr->free_pages == 0) {
        hdr = hz3_seg_alloc_small(t_hz3_cache.my_shard);
        if (!hdr) {
            return NULL;
        }
        t_hz3_cache.small_current_seg = hdr;
    }

    int start_page = hz3_bitmap_find_free(hdr->free_bits, 1);
    if (start_page < 0) {
        hdr = hz3_seg_alloc_small(t_hz3_cache.my_shard);
        if (!hdr) {
            return NULL;
        }
        t_hz3_cache.small_current_seg = hdr;
        start_page = hz3_bitmap_find_free(hdr->free_bits, 1);
        if (start_page < 0) {
            return NULL;
        }
    }

    hz3_bitmap_mark_used(hdr->free_bits, (size_t)start_page, 1);
    if (hdr->free_pages > 0) {
        hdr->free_pages--;
    }

    char* page_base = (char*)hdr + ((size_t)start_page << HZ3_PAGE_SHIFT);
    Hz3SmallV2PageHdr* ph = (Hz3SmallV2PageHdr*)page_base;
    ph->magic = HZ3_PAGE_MAGIC;
    ph->owner = hdr->owner;  // seg_hdr から複製
    ph->sc = (uint8_t)sc;
    ph->flags = 0;
    ph->reserved = 0;

#if HZ3_SMALL_V2_PTAG_ENABLE || HZ3_PTAG_DSTBIN_ENABLE
    uint32_t page_idx;
    if (hz3_arena_page_index_fast(page_base, &page_idx)) {
#if HZ3_SMALL_V2_PTAG_ENABLE
        // S12-4B: event-only tag set (page allocation boundary)
        hz3_pagetag_set(page_idx, sc, (int)hdr->owner);
#endif
#if HZ3_PTAG_DSTBIN_ENABLE
        // S17: dst/bin direct tag set (page allocation boundary)
        int bin = hz3_bin_index_small(sc);
        if (g_hz3_page_tag32) {
            uint32_t tag = hz3_pagetag32_encode(bin, (int)hdr->owner);
            hz3_pagetag32_store(page_idx, tag);
        }
#endif
    }
#endif

    return page_base;
}

static void hz3_small_v2_fill_bin(Hz3Bin* bin, int sc, void* page_base) {
    size_t obj_size = hz3_small_sc_to_size(sc);
    uintptr_t start = (uintptr_t)page_base + HZ3_SMALL_V2_PAGE_HDR_SIZE;
    start = (start + (HZ3_SMALL_ALIGN - 1u)) & ~(uintptr_t)(HZ3_SMALL_ALIGN - 1u);

    size_t available = HZ3_PAGE_SIZE - (start - (uintptr_t)page_base);
    size_t count = available / obj_size;
    if (count == 0) {
        return;
    }

    char* cur = (char*)start;
    for (size_t i = 0; i + 1 < count; i++) {
        hz3_obj_set_next(cur, cur + obj_size);
        cur += obj_size;
    }
    hz3_obj_set_next(cur, bin->head);
    bin->head = (void*)start;
    bin->count += (uint16_t)count;
}
#endif

void* hz3_small_v2_alloc_slow(int sc) {
#if !HZ3_SMALL_V2_ENABLE || !HZ3_SEG_SELF_DESC_ENABLE
    (void)sc;
    return NULL;
#else
    if (sc < 0 || sc >= HZ3_SMALL_NUM_SC) {
        return NULL;
    }

    Hz3Bin* bin = hz3_tcache_get_small_bin(sc);
    hz3_small_v2_central_init();

    void* batch[HZ3_SMALL_V2_REFILL_BATCH];
    int got = hz3_small_v2_central_pop_batch(t_hz3_cache.my_shard, sc, batch, HZ3_SMALL_V2_REFILL_BATCH);
    if (got > 0) {
        for (int i = 1; i < got; i++) {
            hz3_bin_push(bin, batch[i]);
        }
        return batch[0];
    }

    void* page = hz3_small_v2_alloc_page(sc);
    if (!page) {
        return NULL;
    }

    hz3_small_v2_fill_bin(bin, sc, page);
    return hz3_bin_pop(bin);
#endif
}

void hz3_small_v2_free_remote_slow(void* ptr, int sc, int owner) {
#if !HZ3_SMALL_V2_ENABLE || !HZ3_SEG_SELF_DESC_ENABLE
    (void)ptr;
    (void)sc;
    (void)owner;
#else
    if (!ptr) {
        return;
    }
    if (sc < 0 || sc >= HZ3_SMALL_NUM_SC) {
        return;
    }

    hz3_small_v2_central_init();
    hz3_small_v2_central_push_list((uint8_t)owner, sc, ptr, ptr, 1);
#endif
}

// Task 3: Fast free using page_hdr only (no seg_hdr read)
void hz3_small_v2_free_fast(void* ptr, void* page_hdr) {
#if !HZ3_SMALL_V2_ENABLE || !HZ3_SEG_SELF_DESC_ENABLE
    (void)ptr;
    (void)page_hdr;
#else
    if (!ptr || !page_hdr) {
        return;
    }

    Hz3SmallV2PageHdr* ph = (Hz3SmallV2PageHdr*)page_hdr;
    int sc = (int)ph->sc;
    if (sc < 0 || sc >= HZ3_SMALL_NUM_SC) {
        return;
    }

    hz3_tcache_ensure_init();

    if (ph->owner == t_hz3_cache.my_shard) {
        hz3_small_v2_free_local_fast(ptr, sc);
        return;
    }

    hz3_small_v2_free_remote_slow(ptr, sc, ph->owner);
#endif
}

// Legacy: kept for compatibility (realloc, etc.)
void hz3_small_v2_free(void* ptr, const Hz3SegHdr* hdr) {
#if !HZ3_SMALL_V2_ENABLE || !HZ3_SEG_SELF_DESC_ENABLE
    (void)ptr;
    (void)hdr;
#else
    if (!ptr || !hdr) {
        return;
    }

    void* page_base = (void*)((uintptr_t)ptr & ~((uintptr_t)HZ3_PAGE_SIZE - 1u));
    Hz3SmallV2PageHdr* ph = (Hz3SmallV2PageHdr*)page_base;
    int sc = (int)ph->sc;
    if (sc < 0 || sc >= HZ3_SMALL_NUM_SC) {
        return;
    }

    hz3_tcache_ensure_init();

    if (hdr->owner == t_hz3_cache.my_shard) {
        hz3_small_v2_free_local_fast(ptr, sc);
        return;
    }

    hz3_small_v2_free_remote_slow(ptr, sc, hdr->owner);
#endif
}

size_t hz3_small_v2_usable_size(void* ptr) {
#if !HZ3_SMALL_V2_ENABLE || !HZ3_SEG_SELF_DESC_ENABLE
    (void)ptr;
    return 0;
#else
    if (!ptr) {
        return 0;
    }

    void* page_base = (void*)((uintptr_t)ptr & ~((uintptr_t)HZ3_PAGE_SIZE - 1u));
    Hz3SmallV2PageHdr* ph = (Hz3SmallV2PageHdr*)page_base;
    int sc = (int)ph->sc;
    if (sc < 0 || sc >= HZ3_SMALL_NUM_SC) {
        return 0;
    }
    return hz3_small_sc_to_size(sc);
#endif
}

void hz3_small_v2_bin_flush(int sc, Hz3Bin* bin) {
#if !HZ3_SMALL_V2_ENABLE || !HZ3_SEG_SELF_DESC_ENABLE
    (void)sc;
    (void)bin;
#else
    if (!bin || !bin->head || bin->count == 0) {
        return;
    }
    if (sc < 0 || sc >= HZ3_SMALL_NUM_SC) {
        return;
    }

    hz3_small_v2_central_init();

    void* head = bin->head;
    void* tail = head;
    uint32_t n = 1;
    void* cur = hz3_obj_get_next(head);
    while (cur) {
        tail = cur;
        n++;
        cur = hz3_obj_get_next(cur);
    }

    hz3_small_v2_central_push_list(t_hz3_cache.my_shard, sc, head, tail, n);
    bin->head = NULL;
    bin->count = 0;
#endif
}
