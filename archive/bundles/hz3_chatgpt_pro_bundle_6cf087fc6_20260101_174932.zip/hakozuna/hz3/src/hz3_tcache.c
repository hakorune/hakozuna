#define _GNU_SOURCE

#include "hz3_tcache.h"
#include "hz3_config.h"
#include "hz3_segment.h"
#include "hz3_segmap.h"
#include "hz3_central.h"
#include "hz3_inbox.h"
#include "hz3_knobs.h"
#include "hz3_epoch.h"
#include "hz3_small.h"
#include "hz3_small_v2.h"
#include "hz3_seg_hdr.h"
#include "hz3_tag.h"
#include "hz3_arena.h"  // S12-5B: for PageTagMap

#include <string.h>
#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>

// Thread-local cache (zero-initialized by TLS semantics)
__thread Hz3TCache t_hz3_cache;

// Day 4: Round-robin shard assignment
static _Atomic uint32_t g_shard_counter = 0;

// Day 5: Thread exit cleanup via pthread_key
static pthread_key_t g_hz3_tcache_key;
static pthread_once_t g_hz3_tcache_key_once = PTHREAD_ONCE_INIT;

#if HZ3_STATS_DUMP && !HZ3_SHIM_FORWARD_ONLY
// S15: Global aggregates for Hz3Stats (refill_calls, central_pop_miss, etc.)
static _Atomic uint32_t g_stats_refill_calls[HZ3_NUM_SC] = {0};
static _Atomic uint32_t g_stats_central_pop_miss[HZ3_NUM_SC] = {0};
static _Atomic uint32_t g_stats_segment_new_count = 0;
static pthread_once_t g_stats_dump_atexit_once = PTHREAD_ONCE_INIT;

static void hz3_stats_aggregate_thread(void) {
    for (int sc = 0; sc < HZ3_NUM_SC; sc++) {
        atomic_fetch_add_explicit(&g_stats_refill_calls[sc],
            t_hz3_cache.stats.refill_calls[sc], memory_order_relaxed);
        atomic_fetch_add_explicit(&g_stats_central_pop_miss[sc],
            t_hz3_cache.stats.central_pop_miss[sc], memory_order_relaxed);
        t_hz3_cache.stats.refill_calls[sc] = 0;
        t_hz3_cache.stats.central_pop_miss[sc] = 0;
    }
    atomic_fetch_add_explicit(&g_stats_segment_new_count,
        t_hz3_cache.stats.segment_new_count, memory_order_relaxed);
    t_hz3_cache.stats.segment_new_count = 0;
}

static void hz3_stats_dump(void) {
    hz3_stats_aggregate_thread();
    fprintf(stderr, "[hz3] S15 stats: seg_new=%u\n",
            atomic_load(&g_stats_segment_new_count));
    fprintf(stderr, "[hz3] refill_calls   :");
    for (int sc = 0; sc < HZ3_NUM_SC; sc++) {
        fprintf(stderr, " [%d]=%u", sc, atomic_load(&g_stats_refill_calls[sc]));
    }
    fprintf(stderr, "\n");
    fprintf(stderr, "[hz3] central_pop_miss:");
    for (int sc = 0; sc < HZ3_NUM_SC; sc++) {
        fprintf(stderr, " [%d]=%u", sc, atomic_load(&g_stats_central_pop_miss[sc]));
    }
    fprintf(stderr, "\n");
}

static void hz3_stats_register_atexit(void) {
    atexit(hz3_stats_dump);
}
#endif

#if HZ3_S12_V2_STATS && !HZ3_SHIM_FORWARD_ONLY
// S12-3C triage: Global aggregates for multi-thread stats
static _Atomic uint64_t g_s12_v2_seg_from_ptr_calls = 0;
static _Atomic uint64_t g_s12_v2_seg_from_ptr_hit = 0;
static _Atomic uint64_t g_s12_v2_seg_from_ptr_miss = 0;
static _Atomic uint64_t g_s12_v2_small_v2_enter = 0;
static pthread_once_t g_s12_v2_stats_atexit_once = PTHREAD_ONCE_INIT;

static void hz3_s12_v2_stats_aggregate_thread(void) {
    atomic_fetch_add_explicit(&g_s12_v2_seg_from_ptr_calls,
        t_hz3_cache.stats.s12_v2_seg_from_ptr_calls, memory_order_relaxed);
    atomic_fetch_add_explicit(&g_s12_v2_seg_from_ptr_hit,
        t_hz3_cache.stats.s12_v2_seg_from_ptr_hit, memory_order_relaxed);
    atomic_fetch_add_explicit(&g_s12_v2_seg_from_ptr_miss,
        t_hz3_cache.stats.s12_v2_seg_from_ptr_miss, memory_order_relaxed);
    atomic_fetch_add_explicit(&g_s12_v2_small_v2_enter,
        t_hz3_cache.stats.s12_v2_small_v2_enter, memory_order_relaxed);
}

static void hz3_s12_v2_stats_dump(void) {
    fprintf(stderr, "[hz3] S12_V2 stats: calls=%lu hit=%lu miss=%lu enter=%lu\n",
            (unsigned long)atomic_load(&g_s12_v2_seg_from_ptr_calls),
            (unsigned long)atomic_load(&g_s12_v2_seg_from_ptr_hit),
            (unsigned long)atomic_load(&g_s12_v2_seg_from_ptr_miss),
            (unsigned long)atomic_load(&g_s12_v2_small_v2_enter));
}

static void hz3_s12_v2_stats_register_atexit(void) {
    atexit(hz3_s12_v2_stats_dump);
}
#endif

#if HZ3_V2_ONLY_STATS && !HZ3_SHIM_FORWARD_ONLY
// S12-8: v2-only PTAG coverage aggregates
static _Atomic uint64_t g_v2_only_tag_load = 0;
static _Atomic uint64_t g_v2_only_tag_zero = 0;
static _Atomic uint64_t g_v2_only_tag_nonzero = 0;
static _Atomic uint64_t g_v2_only_dispatch_v2 = 0;
static _Atomic uint64_t g_v2_only_dispatch_v1 = 0;
static pthread_once_t g_v2_only_stats_atexit_once = PTHREAD_ONCE_INIT;

static void hz3_v2_only_stats_aggregate_thread(void) {
    atomic_fetch_add_explicit(&g_v2_only_tag_load,
        t_hz3_cache.stats.v2_only_tag_load, memory_order_relaxed);
    atomic_fetch_add_explicit(&g_v2_only_tag_zero,
        t_hz3_cache.stats.v2_only_tag_zero, memory_order_relaxed);
    atomic_fetch_add_explicit(&g_v2_only_tag_nonzero,
        t_hz3_cache.stats.v2_only_tag_nonzero, memory_order_relaxed);
    atomic_fetch_add_explicit(&g_v2_only_dispatch_v2,
        t_hz3_cache.stats.v2_only_dispatch_v2, memory_order_relaxed);
    atomic_fetch_add_explicit(&g_v2_only_dispatch_v1,
        t_hz3_cache.stats.v2_only_dispatch_v1, memory_order_relaxed);

    // Avoid double counting if atexit runs before TLS destructor.
    t_hz3_cache.stats.v2_only_tag_load = 0;
    t_hz3_cache.stats.v2_only_tag_zero = 0;
    t_hz3_cache.stats.v2_only_tag_nonzero = 0;
    t_hz3_cache.stats.v2_only_dispatch_v2 = 0;
    t_hz3_cache.stats.v2_only_dispatch_v1 = 0;
}

static void hz3_v2_only_stats_dump(void) {
    hz3_v2_only_stats_aggregate_thread();
    fprintf(stderr,
            "[hz3] V2_ONLY stats: tag_load=%lu tag_zero=%lu tag_nonzero=%lu v2=%lu v1=%lu\n",
            (unsigned long)atomic_load(&g_v2_only_tag_load),
            (unsigned long)atomic_load(&g_v2_only_tag_zero),
            (unsigned long)atomic_load(&g_v2_only_tag_nonzero),
            (unsigned long)atomic_load(&g_v2_only_dispatch_v2),
            (unsigned long)atomic_load(&g_v2_only_dispatch_v1));
}

static void hz3_v2_only_stats_register_atexit(void) {
    atexit(hz3_v2_only_stats_dump);
}
#endif

// Forward declaration
void hz3_outbox_flush(uint8_t owner, int sc);

static void hz3_tcache_destructor(void* arg) {
    (void)arg;
    if (!t_hz3_cache.initialized) return;

#if HZ3_S12_V2_STATS && !HZ3_SHIM_FORWARD_ONLY
    // S12-3C triage: Aggregate thread stats before cleanup
    hz3_s12_v2_stats_aggregate_thread();
#endif
#if HZ3_V2_ONLY_STATS && !HZ3_SHIM_FORWARD_ONLY
    // S12-8: Aggregate v2-only PTAG coverage stats
    hz3_v2_only_stats_aggregate_thread();
#endif
    // Day 6: Force epoch cleanup first
    hz3_epoch_force();

#if HZ3_PTAG_DSTBIN_ENABLE
    // S17: Flush remote banks (event-only)
    hz3_dstbin_flush_remote();
#endif

    // 1. Flush all outboxes (redundant after epoch, but safe)
    for (int owner = 0; owner < HZ3_NUM_SHARDS; owner++) {
        for (int sc = 0; sc < HZ3_NUM_SC; sc++) {
            hz3_outbox_flush((uint8_t)owner, sc);
        }
    }

    // 2. Return bins to central (batch)
    for (int sc = 0; sc < HZ3_NUM_SC; sc++) {
        Hz3Bin* bin = hz3_tcache_get_bin(sc);
        if (bin->head && bin->count > 0) {
            // Build list: find tail
            void* head = bin->head;
            void* tail = head;
            uint32_t n = 1;
            void* obj = hz3_obj_get_next(head);
            while (obj) {
                tail = obj;
                n++;
                obj = hz3_obj_get_next(obj);
            }
            hz3_central_push_list(t_hz3_cache.my_shard, sc, head, tail, n);
            bin->head = NULL;
            bin->count = 0;
        }
    }

    // 3. Return small bins to central
    for (int sc = 0; sc < HZ3_SMALL_NUM_SC; sc++) {
#if HZ3_SMALL_V2_ENABLE
        hz3_small_v2_bin_flush(sc, hz3_tcache_get_small_bin(sc));
#elif HZ3_SMALL_V1_ENABLE
        hz3_small_bin_flush(sc, hz3_tcache_get_small_bin(sc));
#endif
    }

    // Note: segment cleanup is deferred to process exit
}

static void hz3_tcache_create_key(void) {
    pthread_key_create(&g_hz3_tcache_key, hz3_tcache_destructor);
}

void hz3_tcache_ensure_init_slow(void) {
    if (t_hz3_cache.initialized) {
        return;
    }

    // Day 5: Register pthread_key destructor (once per process)
    pthread_once(&g_hz3_tcache_key_once, hz3_tcache_create_key);
    pthread_setspecific(g_hz3_tcache_key, &t_hz3_cache);

#if HZ3_STATS_DUMP && !HZ3_SHIM_FORWARD_ONLY
    // S15: Register atexit stats dump (once per process)
    pthread_once(&g_stats_dump_atexit_once, hz3_stats_register_atexit);
#endif
#if HZ3_S12_V2_STATS && !HZ3_SHIM_FORWARD_ONLY
    // S12-3C triage: Register atexit stats dump (once per process)
    pthread_once(&g_s12_v2_stats_atexit_once, hz3_s12_v2_stats_register_atexit);
#endif
#if HZ3_V2_ONLY_STATS && !HZ3_SHIM_FORWARD_ONLY
    // S12-8: Register atexit stats dump (once per process)
    pthread_once(&g_v2_only_stats_atexit_once, hz3_v2_only_stats_register_atexit);
#endif
    // 1. Shard assignment FIRST (before any segment creation)
    t_hz3_cache.my_shard = atomic_fetch_add(&g_shard_counter, 1) % HZ3_NUM_SHARDS;

    // 2. Initialize central pool (thread-safe via pthread_once)
    hz3_central_init();

    // 3. Initialize inbox pool (thread-safe via pthread_once)
    hz3_inbox_init();

    // 4. Initialize bins and outbox
    memset(t_hz3_cache.bins, 0, sizeof(t_hz3_cache.bins));
    memset(t_hz3_cache.small_bins, 0, sizeof(t_hz3_cache.small_bins));
    memset(t_hz3_cache.outbox, 0, sizeof(t_hz3_cache.outbox));
#if HZ3_PTAG_DSTBIN_ENABLE
    memset(t_hz3_cache.bank, 0, sizeof(t_hz3_cache.bank));
#if HZ3_PTAG_DSTBIN_TLS
    t_hz3_cache.arena_base =
        atomic_load_explicit(&g_hz3_arena_base, memory_order_acquire);
    t_hz3_cache.page_tag32 = g_hz3_page_tag32;
#endif
#endif

    // 5. No current segment yet
    t_hz3_cache.current_seg = NULL;
    t_hz3_cache.small_current_seg = NULL;

    // 6. Day 6: Initialize knobs (thread-safe via pthread_once)
    hz3_knobs_init();

    // 7. Day 6: Copy global knobs to TLS snapshot
    t_hz3_cache.knobs = g_hz3_knobs;
    t_hz3_cache.knobs_ver = atomic_load_explicit(&g_hz3_knobs_ver, memory_order_acquire);

    // 8. Day 6: Initialize stats to zero
    memset(&t_hz3_cache.stats, 0, sizeof(t_hz3_cache.stats));

    t_hz3_cache.initialized = 1;
}

// ============================================================================
// Day 4: Outbox operations
// ============================================================================

// Flush outbox to owner's inbox (FIFO order)
void hz3_outbox_flush(uint8_t owner, int sc) {
    Hz3OutboxBin* ob = &t_hz3_cache.outbox[owner][sc];
    if (ob->count == 0) return;

    // Build FIFO linked list: slots[0] -> slots[1] -> ... -> slots[count-1]
    void* head = ob->slots[0];
    for (uint8_t i = 0; i < ob->count - 1; i++) {
        hz3_obj_set_next(ob->slots[i], ob->slots[i + 1]);
    }
    hz3_obj_set_next(ob->slots[ob->count - 1], NULL);
    void* tail = ob->slots[ob->count - 1];

    // Push to inbox
    hz3_inbox_push_list(owner, sc, head, tail, ob->count);
    ob->count = 0;
}

// Push to outbox, flush if full
void hz3_outbox_push(uint8_t owner, int sc, void* obj) {
    Hz3OutboxBin* ob = &t_hz3_cache.outbox[owner][sc];
    ob->slots[ob->count++] = obj;

    if (ob->count >= HZ3_OUTBOX_SIZE) {
        hz3_outbox_flush(owner, sc);
    }
}

#if HZ3_PTAG_DSTBIN_ENABLE
// ============================================================================
// S17: dst/bin direct remote bank flush (event-only)
// ============================================================================
static void hz3_dstbin_detach(Hz3Bin* bin, void** head_out, void** tail_out, uint32_t* n_out) {
    void* head = bin->head;
    if (!head) {
        *head_out = NULL;
        *tail_out = NULL;
        *n_out = 0;
        return;
    }
    void* tail = head;
    uint32_t n = 1;
    void* cur = hz3_obj_get_next(head);
    while (cur) {
        tail = cur;
        n++;
        cur = hz3_obj_get_next(cur);
    }
    bin->head = NULL;
    bin->count = 0;
    *head_out = head;
    *tail_out = tail;
    *n_out = n;
}

void hz3_dstbin_flush_remote(void) {
    uint8_t my_shard = t_hz3_cache.my_shard;
    for (uint8_t dst = 0; dst < HZ3_NUM_SHARDS; dst++) {
        if (dst == my_shard) {
            continue;
        }
        for (int bin = 0; bin < HZ3_BIN_TOTAL; bin++) {
            Hz3Bin* b = hz3_tcache_get_bank_bin(dst, bin);
            if (!b->head) {
                continue;
            }
            void* head;
            void* tail;
            uint32_t n;
            hz3_dstbin_detach(b, &head, &tail, &n);
            if (!head) {
                continue;
            }
            if (bin < HZ3_SMALL_NUM_SC) {
                hz3_small_v2_push_remote_list(dst, bin, head, tail, n);
            } else {
                int sc = bin - HZ3_SMALL_NUM_SC;
                hz3_inbox_push_list(dst, sc, head, tail, n);
            }
        }
    }
}
#endif

// ============================================================================
// Day 3: Slow path with segment reuse
// ============================================================================

// Allocate from current segment (or new segment if needed)
static void* hz3_slow_alloc_from_segment(int sc) {
    Hz3SegMeta* meta = t_hz3_cache.current_seg;
    size_t pages = hz3_sc_to_pages(sc);

    // If no current segment or not enough space, get new segment
    if (!meta || meta->free_pages < pages) {
        meta = hz3_new_segment(t_hz3_cache.my_shard);
        if (!meta) {
            return NULL;  // OOM
        }
        t_hz3_cache.current_seg = meta;
    }

    // Allocate run from segment
    int start_page = hz3_segment_alloc_run(meta, pages);
    if (start_page < 0) {
        // This shouldn't happen if free_pages check above is correct
        // Try getting a new segment as fallback
        meta = hz3_new_segment(t_hz3_cache.my_shard);
        if (!meta) {
            return NULL;
        }
        t_hz3_cache.current_seg = meta;
        start_page = hz3_segment_alloc_run(meta, pages);
        if (start_page < 0) {
            return NULL;  // Shouldn't happen
        }
    }

    // Set tags for all pages in run
    uint16_t tag = hz3_tag_make_large(sc);
    for (size_t i = 0; i < pages; i++) {
        meta->sc_tag[start_page + i] = tag;
    }

    // Convert to pointer
    void* run_base = (char*)meta->seg_base + ((size_t)start_page << HZ3_PAGE_SHIFT);

#if (HZ3_SMALL_V2_PTAG_ENABLE && HZ3_PTAG_V1_ENABLE) || HZ3_PTAG_DSTBIN_ENABLE
    // Set PageTagMap tags for medium allocations (all pages in run)
    uint32_t base_page_idx;
    if (hz3_arena_page_index_fast(run_base, &base_page_idx)) {
#if HZ3_SMALL_V2_PTAG_ENABLE && HZ3_PTAG_V1_ENABLE
        // S12-5B: v1 medium tag
        uint16_t ptag = hz3_pagetag_encode_v1(sc, t_hz3_cache.my_shard);
        for (size_t i = 0; i < pages; i++) {
            hz3_pagetag_store(base_page_idx + (uint32_t)i, ptag);
        }
#endif
#if HZ3_PTAG_DSTBIN_ENABLE
        // S17: dst/bin direct tag
        int bin = hz3_bin_index_medium(sc);
        if (g_hz3_page_tag32) {
            uint32_t tag = hz3_pagetag32_encode(bin, t_hz3_cache.my_shard);
            for (size_t i = 0; i < pages; i++) {
                hz3_pagetag32_store(base_page_idx + (uint32_t)i, tag);
            }
        }
#endif
    }
#endif

    return run_base;
}

// Day 5: Slow path with batch refill (inbox -> central -> segment)
void* hz3_alloc_slow(int sc) {
    Hz3Bin* bin = hz3_tcache_get_bin(sc);
    int want = HZ3_REFILL_BATCH[sc];

    // Day 6: Update stats
    t_hz3_cache.stats.refill_calls[sc]++;

#if HZ3_PTAG_DSTBIN_ENABLE
    // S17: Flush remote banks before drain-first (event-only)
    hz3_dstbin_flush_remote();
#endif

    // 1. Drain inbox first (already batches to bin)
    void* obj = hz3_inbox_drain(t_hz3_cache.my_shard, sc, bin);
    if (obj) {
        hz3_epoch_maybe();  // Day 6: epoch check
        return obj;
    }

    // 2. Batch pop from central pool
    void* batch[16];
    int got = hz3_central_pop_batch(t_hz3_cache.my_shard, sc, batch, want);
    if (got > 0) {
        // Push remaining to bin, return first
        for (int i = 1; i < got; i++) {
            hz3_bin_push(bin, batch[i]);
        }
        // Day 6: Update stats
        t_hz3_cache.stats.central_pop_hit[sc]++;
        hz3_epoch_maybe();  // Day 6: epoch check
        return batch[0];
    }
    // Day 6: Update stats
    t_hz3_cache.stats.central_pop_miss[sc]++;

    // 3. Batch allocate from segment
    obj = NULL;
    for (int i = 0; i < want; i++) {
        void* run = hz3_slow_alloc_from_segment(sc);
        if (!run) break;
        if (i == 0) {
            obj = run;  // First one to return
        } else {
            hz3_bin_push(bin, run);
        }
    }
    hz3_epoch_maybe();  // Day 6: epoch check
    return obj;
}
