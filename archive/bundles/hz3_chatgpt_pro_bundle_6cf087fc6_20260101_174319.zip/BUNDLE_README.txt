hz3 ChatGPT Pro bundle (post-S17)

- git: 6cf087fc6
- created: 20260101_174319

Open:
- hakozuna/hz3/docs/CHATGPT_PRO_PROMPT_S18_POST_S17_NEXT_1PCT.md
