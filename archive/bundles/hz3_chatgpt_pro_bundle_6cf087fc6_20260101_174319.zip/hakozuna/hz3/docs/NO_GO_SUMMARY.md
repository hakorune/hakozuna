# hz3 NO-GO Summary（研究箱のアーカイブ索引）

目的:
- “試したが負けた/戻した” を再発防止のために SSOT ログ付きで固定する。
- 研究コードは本線（`hakozuna/hz3/src`）に残さず、`hakozuna/hz3/archive/research/` へ退避する。

運用:
- **1 experiment = 1 folder**
- 必須: `README.md`（目的/変更/GO条件/結果/ログ/復活条件）
- SSOT ログは `/tmp/...` のパスを残す（再計測の入口も書く）

---

## Current NO-GO / Defer List

- xfer transfer cache（NO-GO）: `hakozuna/hz3/archive/research/xfer_transfer_cache/README.md`
- slow-start refill（NO-GO）: `hakozuna/hz3/archive/research/slow_start_refill/README.md`
- dynamic bin cap（NO-GO寄り）: `hakozuna/hz3/archive/research/bin_cap_dynamic/README.md`
- S13 transfer cache（NO-GO）: `hakozuna/hz3/archive/research/s13_transfer_cache/README.md`
- S16-2 PTAG layout v2（NO-GO）: `hakozuna/hz3/archive/research/s16_2_ptag_layout_v2/README.md`
- S16-2C tag decode lifetime split（NO-GO）: `hakozuna/hz3/archive/research/s16_2c_tag_decode_lifetime/README.md`
- S16-2D free fastpath shape split（NO-GO）: `hakozuna/hz3/archive/research/s16_2d_free_fastpath_shape/README.md`
- S17 PTAG dst/bin TLS snapshot（NO-GO）: `hakozuna/hz3/archive/research/s17_ptag_dstbin_tls/README.md`
- S18-2 PTAG 16-bit（NO-GO）: `hakozuna/hz3/archive/research/s18_2_ptag16/README.md`

補足:
- “NO-GOの結果” はまとめて `hakozuna/hz3/docs/PHASE_HZ3_S12_7_BATCH_TUNING_AND_NO_GO.md` にも記録している。
