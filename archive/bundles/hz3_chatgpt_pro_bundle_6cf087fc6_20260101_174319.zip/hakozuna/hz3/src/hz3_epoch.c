#define _GNU_SOURCE

#include "hz3_epoch.h"
#include "hz3_tcache.h"
#include "hz3_knobs.h"
#include "hz3_central.h"
#include "hz3_learn.h"

#include <string.h>

// ============================================================================
// Day 6: Epoch - periodic maintenance
// Actions:
//   1. Flush all outboxes
//   2. Trim bins (excess -> central)
//   3. Update knobs snapshot if version changed
// ============================================================================

// TLS epoch state
static __thread uint64_t t_epoch_counter = 0;
static __thread int t_in_epoch = 0;  // re-entry guard

// Forward declarations
extern __thread Hz3TCache t_hz3_cache;
void hz3_outbox_flush(uint8_t owner, int sc);

// Trim bin to target, return excess to central
static void hz3_bin_trim(int sc, uint8_t target) {
    Hz3Bin* bin = hz3_tcache_get_bin(sc);
    if (bin->count <= target) return;

    uint32_t excess = bin->count - target;
    uint32_t batch = excess;
    void* head = bin->head;
    void* tail = head;
    uint32_t n = 1;

    // Cut off 'batch' objects from bin
    while (n < batch && hz3_obj_get_next(tail)) {
        tail = hz3_obj_get_next(tail);
        n++;
    }

    // Update bin
    bin->head = hz3_obj_get_next(tail);
    bin->count -= n;
    hz3_obj_set_next(tail, NULL);

    // Update stats
    t_hz3_cache.stats.bin_trim_excess[sc] += n;

    // Return to central
    hz3_central_push_list(t_hz3_cache.my_shard, sc, head, tail, n);
}

void hz3_epoch_maybe(void) {
    if (++t_epoch_counter < HZ3_EPOCH_INTERVAL) return;
    t_epoch_counter = 0;
    hz3_epoch_force();
}

void hz3_epoch_force(void) {
    // Re-entry guard (destructor / slow path / flush could overlap)
    if (t_in_epoch) return;
    t_in_epoch = 1;

    // 1. Flush all outboxes
    for (int owner = 0; owner < HZ3_NUM_SHARDS; owner++) {
        for (int sc = 0; sc < HZ3_NUM_SC; sc++) {
            hz3_outbox_flush((uint8_t)owner, sc);
        }
    }

#if HZ3_PTAG_DSTBIN_ENABLE
    // S17: Flush remote banks to inbox/central (event-only)
    hz3_dstbin_flush_remote();
#endif

    // 2. Trim bins to target
    for (int sc = 0; sc < HZ3_NUM_SC; sc++) {
        hz3_bin_trim(sc, t_hz3_cache.knobs.bin_target[sc]);
    }

    // 3. Update knobs snapshot if version changed
    uint32_t ver = atomic_load_explicit(&g_hz3_knobs_ver, memory_order_acquire);
    if (t_hz3_cache.knobs_ver != ver) {
        t_hz3_cache.knobs = g_hz3_knobs;  // struct copy
        t_hz3_cache.knobs_ver = ver;
    }

    // 4. Day 6: Learning v0 (only when HZ3_LEARN_ENABLE=1)
    hz3_learn_update(&t_hz3_cache.stats);

    t_in_epoch = 0;
}
