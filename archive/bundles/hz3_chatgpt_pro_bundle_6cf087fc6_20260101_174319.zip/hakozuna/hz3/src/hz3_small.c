#include "hz3_small.h"

#include "hz3_arena.h"
#include "hz3_segment.h"
#include "hz3_tag.h"
#include "hz3_tcache.h"

#include <pthread.h>
#include <stdint.h>

#if !HZ3_SMALL_V1_ENABLE
void* hz3_small_alloc(size_t size) {
    (void)size;
    return NULL;
}

void hz3_small_free(void* ptr, int sc) {
    (void)ptr;
    (void)sc;
}

void hz3_small_bin_flush(int sc, Hz3Bin* bin) {
    (void)sc;
    (void)bin;
}

#if HZ3_SMALL_V2_PTAG_ENABLE && HZ3_PTAG_V1_ENABLE
void hz3_small_free_by_tag(void* ptr, int sc, int owner) {
    (void)ptr;
    (void)sc;
    (void)owner;
}
#endif

#else  // HZ3_SMALL_V1_ENABLE

#define HZ3_SMALL_REFILL_BATCH 32

typedef struct {
    pthread_mutex_t lock;
    void* head;
    uint32_t count;
} Hz3SmallCentralBin;

static pthread_once_t g_hz3_small_central_once = PTHREAD_ONCE_INIT;
static Hz3SmallCentralBin g_hz3_small_central[HZ3_SMALL_NUM_SC];

static void hz3_small_central_do_init(void) {
    for (int sc = 0; sc < HZ3_SMALL_NUM_SC; sc++) {
        Hz3SmallCentralBin* bin = &g_hz3_small_central[sc];
        pthread_mutex_init(&bin->lock, NULL);
        bin->head = NULL;
        bin->count = 0;
    }
}

static inline void hz3_small_central_init(void) {
    pthread_once(&g_hz3_small_central_once, hz3_small_central_do_init);
}

static void hz3_small_central_push_list(int sc, void* head, void* tail, uint32_t n) {
    if (!head || !tail || n == 0) {
        return;
    }
    Hz3SmallCentralBin* bin = &g_hz3_small_central[sc];
    pthread_mutex_lock(&bin->lock);
    hz3_obj_set_next(tail, bin->head);
    bin->head = head;
    bin->count += n;
    pthread_mutex_unlock(&bin->lock);
}

static int hz3_small_central_pop_batch(int sc, void** out, int want) {
    Hz3SmallCentralBin* bin = &g_hz3_small_central[sc];
    pthread_mutex_lock(&bin->lock);
    int got = 0;
    while (got < want && bin->head) {
        void* cur = bin->head;
        void* next = hz3_obj_get_next(cur);
        out[got++] = cur;
        bin->head = next;
        bin->count--;
    }
    pthread_mutex_unlock(&bin->lock);
    return got;
}

static void* hz3_small_alloc_page(int sc) {
    Hz3SegMeta* meta = t_hz3_cache.current_seg;

    if (!meta || meta->free_pages < 1) {
        meta = hz3_new_segment(t_hz3_cache.my_shard);
        if (!meta) {
            return NULL;
        }
        t_hz3_cache.current_seg = meta;
    }

    int start_page = hz3_segment_alloc_run(meta, 1);
    if (start_page < 0) {
        meta = hz3_new_segment(t_hz3_cache.my_shard);
        if (!meta) {
            return NULL;
        }
        t_hz3_cache.current_seg = meta;
        start_page = hz3_segment_alloc_run(meta, 1);
        if (start_page < 0) {
            return NULL;
        }
    }

    meta->sc_tag[start_page] = hz3_tag_make_small(sc);
    void* page_base = (char*)meta->seg_base + ((size_t)start_page << HZ3_PAGE_SHIFT);

#if (HZ3_SMALL_V2_PTAG_ENABLE && HZ3_PTAG_V1_ENABLE) || HZ3_PTAG_DSTBIN_ENABLE
    // This page is in arena (since S12-5A), so page_idx is valid
    uint32_t page_idx;
    if (hz3_arena_page_index_fast(page_base, &page_idx)) {
#if HZ3_SMALL_V2_PTAG_ENABLE && HZ3_PTAG_V1_ENABLE
        // S12-5B: Set PageTagMap tag for v1 allocation
        uint16_t tag = hz3_pagetag_encode_v1(sc, t_hz3_cache.my_shard);
        hz3_pagetag_store(page_idx, tag);
#endif
#if HZ3_PTAG_DSTBIN_ENABLE
        // S17: dst/bin direct tag set (page allocation boundary)
        int bin = hz3_bin_index_medium(sc);
        if (g_hz3_page_tag32) {
            uint32_t tag32 = hz3_pagetag32_encode(bin, t_hz3_cache.my_shard);
            hz3_pagetag32_store(page_idx, tag32);
        }
#endif
    }
#endif

    return page_base;
}

static void hz3_small_fill_bin(Hz3Bin* bin, int sc, void* page_base) {
    size_t obj_size = hz3_small_sc_to_size(sc);
    size_t count = HZ3_PAGE_SIZE / obj_size;
    char* cur = (char*)page_base;

    for (size_t i = 0; i + 1 < count; i++) {
        hz3_obj_set_next(cur, cur + obj_size);
        cur += obj_size;
    }
    hz3_obj_set_next(cur, bin->head);
    bin->head = page_base;
    bin->count += (uint16_t)count;
}

void* hz3_small_alloc(size_t size) {
    int sc = hz3_small_sc_from_size(size);
    if (sc < 0 || sc >= HZ3_SMALL_NUM_SC) {
        return NULL;
    }

    hz3_tcache_ensure_init();
    Hz3Bin* bin = hz3_tcache_get_small_bin(sc);

    void* obj = hz3_bin_pop(bin);
    if (obj) {
        return obj;
    }

    hz3_small_central_init();

    void* batch[HZ3_SMALL_REFILL_BATCH];
    int got = hz3_small_central_pop_batch(sc, batch, HZ3_SMALL_REFILL_BATCH);
    if (got > 0) {
        for (int i = 1; i < got; i++) {
            hz3_bin_push(bin, batch[i]);
        }
        return batch[0];
    }

    void* page = hz3_small_alloc_page(sc);
    if (!page) {
        return NULL;
    }

    hz3_small_fill_bin(bin, sc, page);
    return hz3_bin_pop(bin);
}

void hz3_small_free(void* ptr, int sc) {
    if (!ptr || sc < 0 || sc >= HZ3_SMALL_NUM_SC) {
        return;
    }

    hz3_tcache_ensure_init();
    Hz3Bin* bin = hz3_tcache_get_small_bin(sc);
    hz3_bin_push(bin, ptr);
}

void hz3_small_bin_flush(int sc, Hz3Bin* bin) {
    if (!bin || !bin->head || bin->count == 0) {
        return;
    }
    if (sc < 0 || sc >= HZ3_SMALL_NUM_SC) {
        return;
    }

    hz3_small_central_init();

    void* head = bin->head;
    void* tail = head;
    uint32_t n = 1;

    void* cur = hz3_obj_get_next(head);
    while (cur) {
        tail = cur;
        n++;
        cur = hz3_obj_get_next(cur);
    }

    hz3_small_central_push_list(sc, head, tail, n);
    bin->head = NULL;
    bin->count = 0;
}

#if HZ3_SMALL_V2_PTAG_ENABLE && HZ3_PTAG_V1_ENABLE
// S12-5C: Free by tag (unified dispatch path for v1)
// Similar to hz3_small_v2_free_by_tag() but for v1 allocations
void hz3_small_free_by_tag(void* ptr, int sc, int owner) {
    if (!ptr || sc < 0 || sc >= HZ3_SMALL_NUM_SC) {
        return;
    }

    hz3_tcache_ensure_init();

    if (__builtin_expect((uint8_t)owner == t_hz3_cache.my_shard, 1)) {
        // Local: push to TLS bin (fast path)
        Hz3Bin* bin = hz3_tcache_get_small_bin(sc);
        hz3_bin_push(bin, ptr);
        return;
    }

    // Remote: push to central (owner-agnostic for v1, unlike v2's per-owner bins)
    hz3_small_central_init();
    hz3_small_central_push_list(sc, ptr, ptr, 1);
}
#endif

#endif  // HZ3_SMALL_V1_ENABLE
